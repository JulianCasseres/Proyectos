﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class TipoConsulta
    {
        private int numero;
        private String descripcion;
        private char estado;

        public TipoConsulta(int numero, string descripcion, char estado)
        {
            this.numero = numero;
            this.descripcion = descripcion;
            this.estado = estado;
        }

        public int getNumero { get => numero; }
        public string getDescripcion { get => descripcion; }
        public char getEstado { get => estado; }
    }
}
