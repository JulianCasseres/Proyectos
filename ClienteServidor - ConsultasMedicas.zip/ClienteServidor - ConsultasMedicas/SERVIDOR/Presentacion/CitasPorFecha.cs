﻿using Entidades;
using Metodos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class CitasPorFecha : Form
    {
        Funcionalidades funcionalidades;
        MetodosBaseDatos metodos = new MetodosBaseDatos();
        List<TipoConsulta> listaTipos = new List<TipoConsulta>();
        List<Cliente> listaClientes = new List<Cliente>();
        List<Doctor> listaDoctores = new List<Doctor>();
        List<String> CitasFecha = new List<String>();

        public CitasPorFecha(Funcionalidades funcionalidades)
        {
            InitializeComponent();
            this.funcionalidades = funcionalidades;
            listaTipos = metodos.TiposConsultaRegistradas();
            listaClientes = metodos.ClientesRegistrados();
            listaDoctores = metodos.DoctoresRegistrados();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string fecha = textBox1.Text;
            CitasFecha = metodos.CitasFecha(fecha);
            dataGridView2.Rows.Clear();
            if(CitasFecha.Count == 0)
            {
                MessageBox.Show("NO Hay Citas Relacionadas a la fecha");
            }
            else
            {
                for (int i = 0; i < CitasFecha.Count; i++)
                {
                    String[] datos = CitasFecha.ElementAt(i).Split(',');
                    dataGridView2.Rows.Add();
                    dataGridView2.Rows[i].Cells[0].Value = datos[0];
                    dataGridView2.Rows[i].Cells[1].Value = datos[1];

                    for (int j = 0; j < listaTipos.Count; j++)
                    {
                        if (datos[2].Equals(listaTipos.ElementAt(j).getNumero.ToString()))
                        {
                            dataGridView2.Rows[i].Cells[2].Value = listaTipos.ElementAt(j).getDescripcion;
                        }
                    }

                    for (int j = 0; j < listaClientes.Count; j++)
                    {
                        if (datos[3].Equals(listaClientes.ElementAt(j).getIdentificacion.ToString()))
                        {
                            dataGridView2.Rows[i].Cells[4].Value = listaClientes.ElementAt(j).getNombre + " " + listaClientes.ElementAt(j).getApellido1 + " " + listaClientes.ElementAt(j).getApellido2;
                        }
                    }

                    for (int j = 0; j < listaDoctores.Count; j++)
                    {
                        if (datos[4].Equals(listaDoctores.ElementAt(j).getIdentificacion.ToString()))
                        {
                            dataGridView2.Rows[i].Cells[3].Value = listaDoctores.ElementAt(j).getNombre + " " + listaDoctores.ElementAt(j).getApellido1 + " " + listaDoctores.ElementAt(j).getApellido2;
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            funcionalidades.Visible = true;
            this.Visible = false;
        }
    }
}
