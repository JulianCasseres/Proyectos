﻿using Entidades;
using Metodos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class CitasPorDoctor : Form
    {
        Funcionalidades funcionalidades;
        MetodosBaseDatos metodos = new MetodosBaseDatos();
        List<Doctor> listaDoctores = new List<Doctor>();
        List<String> CitasDoctor = new List<String>();

        public CitasPorDoctor(Funcionalidades funcionalidades)
        {
            InitializeComponent();
            this.funcionalidades = funcionalidades;
            listaDoctores = metodos.DoctoresRegistrados();
            Mostrar_Doctores();
        }

        private void Mostrar_Doctores()
        {
            for (int i = 0; i < listaDoctores.Count; i++)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[i].Cells[0].Value = listaDoctores.ElementAt(i).getIdentificacion;
                dataGridView1.Rows[i].Cells[1].Value = listaDoctores.ElementAt(i).getNombre;
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int fila = e.RowIndex;
            if (fila != -1)
            {
                int IdDoctor = int.Parse(dataGridView1.Rows[fila].Cells[0].Value.ToString());
                CitasDoctor = metodos.CitasDoctor(IdDoctor);

                dataGridView2.Rows.Clear();
                if (CitasDoctor.Count == 0)
                {
                    MessageBox.Show("NO Hay Citas Relacionadas al Doctor");
                }
                else
                {
                    for (int i = 0; i < CitasDoctor.Count; i++)
                    {
                        String[] datos = CitasDoctor.ElementAt(i).Split(',');
                        dataGridView2.Rows.Add();
                        dataGridView2.Rows[i].Cells[0].Value = datos[0];
                        dataGridView2.Rows[i].Cells[1].Value = datos[1];
                        dataGridView2.Rows[i].Cells[2].Value = datos[2];
                        dataGridView2.Rows[i].Cells[3].Value = datos[3];
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            funcionalidades.Visible = true;
            this.Visible = false;
        }
    }
}
