﻿using Entidades;
using Metodos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class AdministrarTiposConsultas : Form
    {
        Funcionalidades funcionalidades;
        MetodosBaseDatos metodos = new MetodosBaseDatos();
        List<TipoConsulta> listaTipos = new List<TipoConsulta>();

        public AdministrarTiposConsultas(Funcionalidades funcionalidades)
        {
            InitializeComponent();
            this.funcionalidades = funcionalidades;
            listaTipos = metodos.TiposConsultaRegistradas();

            comboBox1.SelectedIndex = 0;
            button2.Enabled = false; button3.Enabled = false;
            Mostrar_TiposConsulta();
        }

        private bool validar_datos(String descripcion, int index)
        {
            if (descripcion.Length == 0 || index == 0)
            {
                return false;
            }
            return true;
        }

        private void Mostrar_TiposConsulta()
        {
            dataGridView1.DataSource = metodos.TiposConsultaRegistradas();
            dataGridView1.Columns["getDescripcion"].Width = 135;
            dataGridView1.Columns["getNumero"].HeaderText = "Numero";
            dataGridView1.Columns["getDescripcion"].HeaderText = "Descripcion";
            dataGridView1.Columns["getEstado"].HeaderText = "Estado";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int numero = int.Parse(textBox1.Text);
                String descripcion = textBox2.Text;
                if (metodos.VerificarTipoConsulta(numero) == null)
                {
                    if (validar_datos(descripcion, comboBox1.SelectedIndex) == true)
                    {
                        if (comboBox1.SelectedIndex == 1)
                        {
                            TipoConsulta tipoConsulta = new TipoConsulta(numero, descripcion, 'A');
                            metodos.AgregarTipoConsulta(tipoConsulta);
                        }
                        else if (comboBox1.SelectedIndex == 2)
                        {
                            TipoConsulta tipoConsulta = new TipoConsulta(numero, descripcion, 'I');
                            metodos.AgregarTipoConsulta(tipoConsulta);
                        }
                        dataGridView1.Enabled = true;
                        MessageBox.Show("Tipo de Consulta Registrada Correctamente");
                        Mostrar_TiposConsulta();
                    }
                    else
                    {
                        MessageBox.Show("Verifique la informacion ingresada y solicitada");
                    }
                }
                else
                {
                    MessageBox.Show("Tipo de Consulta ya registrada");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Error en el campo numero");
            }
            textBox1.Text = ""; textBox2.Text = ""; comboBox1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int numero = int.Parse(textBox1.Text);
            String descripcion = textBox2.Text;
            if (comboBox1.SelectedIndex == 0)
            {
                MessageBox.Show("Hubo un Error, NO se realizaron los cambios");
            }
            else
            {
                if (comboBox1.SelectedIndex == 1)
                {
                    TipoConsulta tipo = new TipoConsulta(numero, descripcion, 'A');
                    metodos.ModificarTipoConsulta(tipo);
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    TipoConsulta tipo = new TipoConsulta(numero, descripcion, 'I');
                    metodos.ModificarTipoConsulta(tipo);
                }
                MessageBox.Show("Tipo de Consulta Modificada Correctamente");
                Mostrar_TiposConsulta();
            }
            textBox1.Text = ""; textBox2.Text = ""; comboBox1.SelectedIndex = 0;
            button1.Enabled = true; button2.Enabled = false; button3.Enabled = false;
            dataGridView1.Enabled = true;
            textBox1.Enabled = true; textBox2.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = ""; textBox2.Text = ""; comboBox1.SelectedIndex = 0;
            textBox1.Enabled = true; textBox2.Enabled = true;
            button1.Enabled = true; button2.Enabled = false; button3.Enabled = false;
            dataGridView1.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            funcionalidades.Visible = true;
            this.Visible = false;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int fila = e.RowIndex;
            if (fila != -1)
            {
                button1.Enabled = false; button4.Enabled = true; button2.Enabled = true; dataGridView1.Enabled = false;
                textBox1.Enabled = false; textBox2.Enabled = false;
                textBox1.Text = dataGridView1.Rows[fila].Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.Rows[fila].Cells[1].Value.ToString();
            }
        }
    }
}
