﻿using Entidades;
using Metodos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class AdministarDoctores : Form
    {
        Funcionalidades funcionalidades;
        MetodosBaseDatos metodos = new MetodosBaseDatos();
        List<Doctor> listaDoctores = new List<Doctor>();

        public AdministarDoctores(Funcionalidades funcionalidades)
        {
            InitializeComponent();
            this.funcionalidades = funcionalidades;
            listaDoctores = metodos.DoctoresRegistrados();

            comboBox1.SelectedIndex = 0;
            button2.Enabled = false; button3.Enabled = false;
            Mostrar_Doctores();
        }

        private bool validar_datos(String nombre, String apellido1, String apellido2, int index)
        {
            if (nombre.Length == 0 || apellido1.Length == 0 || apellido2.Length == 0 || index == 0)
            {
                return false;
            }
            return true;
        }
        
        private void Mostrar_Doctores()
        {
            dataGridView1.DataSource = metodos.DoctoresRegistrados();
            dataGridView1.Columns["getNombre"].Width = 150;
            dataGridView1.Columns["getApellido1"].Width = 150;
            dataGridView1.Columns["getApellido2"].Width = 150;
            dataGridView1.Columns["getIdentificacion"].HeaderText = "ID";
            dataGridView1.Columns["getNombre"].HeaderText = "Nombre";
            dataGridView1.Columns["getApellido1"].HeaderText = "Apellido1";
            dataGridView1.Columns["getApellido2"].HeaderText = "Apellido2";
            dataGridView1.Columns["getEstado"].HeaderText = "Estado";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int identificacion = int.Parse(textBox1.Text);
                String nombre = textBox2.Text;
                String apellido1 = textBox3.Text;
                String apellido2 = textBox4.Text;
                if (metodos.VerificarDoctor(identificacion) == null)
                {
                    if (validar_datos(nombre, apellido1, apellido2, comboBox1.SelectedIndex))
                    {
                        if (comboBox1.SelectedIndex == 1)
                        {
                            Doctor doctor = new Doctor(identificacion, nombre, apellido1, apellido2, 'A');
                            metodos.AgregarDoctor(doctor);
                        }
                        else if (comboBox1.SelectedIndex == 2)
                        {
                            Doctor doctor = new Doctor(identificacion, nombre, apellido1, apellido2, 'I');
                            metodos.AgregarDoctor(doctor);
                        }
                        MessageBox.Show("Doctor Registrado Correctamente");
                        dataGridView1.Enabled = true;
                        Mostrar_Doctores();
                    }
                    else
                    {
                        MessageBox.Show("Verifique la informacion ingresada y solicitada");
                    }
                }
                else
                {
                    MessageBox.Show("Doctor ya registrado");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Error en el campo ID");
            }
            textBox1.Text = ""; textBox2.Text = ""; textBox3.Text = "";
            textBox4.Text = ""; comboBox1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int identificacion = int.Parse(textBox1.Text);
            String nombre = textBox2.Text;
            String apellido1 = textBox3.Text;
            String apellido2 = textBox4.Text;
            if (comboBox1.SelectedIndex == 0)
            {
                MessageBox.Show("Hubo un Error, NO se realizaron los cambios");
            }
            else
            {
                if (comboBox1.SelectedIndex == 1)
                {
                    Doctor doctor = new Doctor(identificacion, nombre, apellido1, apellido2, 'A');
                    metodos.ModificarDoctor(doctor);
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    Doctor doctor = new Doctor(identificacion, nombre, apellido1, apellido2, 'I');
                    metodos.ModificarDoctor(doctor);
                }
                MessageBox.Show("Doctor Modificado Correctamente");
                Mostrar_Doctores();
            }

            textBox1.Text = ""; textBox2.Text = "";
            textBox3.Text = ""; textBox4.Text = "";
            comboBox1.SelectedIndex = 0;
            textBox1.Enabled = true; textBox2.Enabled = true;
            textBox3.Enabled = true; textBox4.Enabled = true;
            button1.Enabled = true; button2.Enabled = false; button3.Enabled = false;
            dataGridView1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = ""; textBox2.Text = "";
            textBox3.Text = ""; textBox4.Text = "";
            comboBox1.SelectedIndex = 0;
            textBox1.Enabled = true; textBox2.Enabled = true;
            textBox3.Enabled = true; textBox4.Enabled = true;
            button1.Enabled = true; button2.Enabled = false; button3.Enabled = false;
            dataGridView1.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            funcionalidades.Visible = true;
            this.Visible = false;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int fila = e.RowIndex;
            if (fila != -1)
            {
                button1.Enabled = false; button2.Enabled = true; button3.Enabled = true; dataGridView1.Enabled = false;
                textBox1.Text = dataGridView1.Rows[fila].Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.Rows[fila].Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.Rows[fila].Cells[2].Value.ToString();
                textBox4.Text = dataGridView1.Rows[fila].Cells[3].Value.ToString();
                textBox1.Enabled = false; textBox2.Enabled = false;
                textBox3.Enabled = false; textBox4.Enabled = false;
            }
        }
    }
}
