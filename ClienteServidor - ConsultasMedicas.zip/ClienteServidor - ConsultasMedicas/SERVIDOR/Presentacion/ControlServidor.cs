﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Metodos;
using System.IO;
using Newtonsoft.Json;
using Entidades;

namespace Presentacion
{
    public partial class ControlServidor : Form
    {
        TcpListener tcpListener;
        Thread subprocesoEscuchaClientes;
        MetodosBaseDatos metodos = new MetodosBaseDatos();
        bool servidorIniciado;

        public ControlServidor()
        {
            InitializeComponent();
            button3.Enabled = false;
        }

        private void EscucharClientes()
        {
            tcpListener.Start();
            try
            {
                while (servidorIniciado)
                {
                    TcpClient client = tcpListener.AcceptTcpClient();
                    Thread clientThread = new Thread(new ParameterizedThreadStart(ComunicacionCliente));
                    clientThread.Start(client);
                }
            }
            catch (Exception)
            {
                return;
            }
        }

        private void ComunicacionCliente(object cliente)
        {
            TcpClient tcCliente = (TcpClient)cliente;
            StreamReader reader = new StreamReader(tcCliente.GetStream());
            StreamWriter servidorStreamWriter = new StreamWriter(tcCliente.GetStream());

            while (servidorIniciado)
            {
                try
                {
                    var mensaje = reader.ReadLine();
                    Socket<object> mensajeRecibido = JsonConvert.DeserializeObject<Socket<object>>(mensaje);
                    SeleccionarMetodo(mensajeRecibido.Metodo, mensaje, ref servidorStreamWriter);
                }
                catch (Exception)
                {
                    break;
                }
            }
            tcCliente.Close();
        }

        public void SeleccionarMetodo(string pMetodo, string mensaje, ref StreamWriter servidorStreamWriter)
        {
            switch (pMetodo)
            {
                case "ConectarCliente":
                    Socket<string> peticionCC = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    if (!metodos.ClientesConectados().Contains(peticionCC.Entidad))
                    {
                        //textBox1.Text = "se ha conectado el cliente de ID: " + peticionCC.Entidad;
                        //textBox1.AppendText(Environment.NewLine);
                    }
                    metodos.ConectarCliente(peticionCC.Entidad);
                    break;

                case "ClientesConectados":
                    List<string> listaConectados = new List<string>();
                    listaConectados = metodos.ClientesConectados();
                    servidorStreamWriter.WriteLine(JsonConvert.SerializeObject(listaConectados));
                    servidorStreamWriter.Flush();
                    break;

                case "DesconectarCliente":
                    Socket<string> mensajeDesconectar = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    metodos.DesconectarCliente(mensajeDesconectar.Entidad);
                    break;

                case "TiposConsultasRegistradas":
                    List<TipoConsulta> listaTipos = new List<TipoConsulta>();
                    List<string> datosTipos = new List<string>();
                    listaTipos = metodos.TiposConsultaRegistradas();
                    for (int i = 0; i < listaTipos.Count; i++)
                    {
                        datosTipos.Add(listaTipos.ElementAt(i).getNumero + "," + listaTipos.ElementAt(i).getDescripcion + "," + listaTipos.ElementAt(i).getEstado);
                    }
                    servidorStreamWriter.WriteLine(JsonConvert.SerializeObject(datosTipos));
                    servidorStreamWriter.Flush();
                    break;

                case "DoctoresRegistrados":
                    List<Doctor> listaDoctores = new List<Doctor>();
                    List<string> datosDoctores = new List<string>();
                    listaDoctores = metodos.DoctoresRegistrados();
                    for(int i=0; i<listaDoctores.Count; i++)
                    {
                        datosDoctores.Add(listaDoctores.ElementAt(i).getIdentificacion + "," + listaDoctores.ElementAt(i).getNombre + "," + listaDoctores.ElementAt(i).getApellido1 + "," + listaDoctores.ElementAt(i).getApellido2 + "," + listaDoctores.ElementAt(i).getEstado);
                    }
                    servidorStreamWriter.WriteLine(JsonConvert.SerializeObject(datosDoctores));
                    servidorStreamWriter.Flush();
                    break;

                case "VerificarCliente":
                    Socket<string> peticionVC = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    Cliente cliente = metodos.VerificarCliente(int.Parse(peticionVC.Entidad.ToString()));
                    servidorStreamWriter.WriteLine(JsonConvert.SerializeObject(cliente.getIdentificacion + "," + cliente.getNombre + " " + cliente.getApellido1 + " " + cliente.getApellido2));
                    servidorStreamWriter.Flush();
                    break;

                case "VerificarTipoConsulta":
                    Socket<string> peticionVTC = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    TipoConsulta tipo = metodos.VerificarTipoConsulta(int.Parse(peticionVTC.Entidad.ToString()));
                    servidorStreamWriter.WriteLine(JsonConvert.SerializeObject(tipo.getNumero + "," + tipo.getDescripcion + "," + tipo.getEstado));
                    servidorStreamWriter.Flush();
                    break;

                case "VerificarDoctor":
                    Socket<string> peticionVD = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    Doctor doctor = metodos.VerificarDoctor(int.Parse(peticionVD.Entidad.ToString()));
                    servidorStreamWriter.WriteLine(JsonConvert.SerializeObject(doctor.getIdentificacion + "," + doctor.getNombre + "," + doctor.getApellido1 + "," + doctor.getApellido2 + "," + doctor.getEstado));
                    servidorStreamWriter.Flush();
                    break;

                case "CitasCliente":
                    Socket<string> peticionCtC = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    List<string> citasCliente = new List<string>();
                    citasCliente = metodos.CitasCliente(int.Parse(peticionCtC.Entidad.ToString()));
                    servidorStreamWriter.WriteLine(JsonConvert.SerializeObject(citasCliente));
                    servidorStreamWriter.Flush();
                    //textBox1.Text = "El cliente de ID: " + peticionCtC.Entidad.ToString() + " ha consultado sus citas";
                    break;

                case "VerificarCita":
                    Socket<string> peticionVCt = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    string[] parametros = peticionVCt.Entidad.ToString().Split(',');
                    bool respuesta;
                    respuesta = metodos.VerificarCita(int.Parse(parametros[0]), Convert.ToDateTime(parametros[1]));
                    servidorStreamWriter.WriteLine(JsonConvert.SerializeObject(respuesta));
                    servidorStreamWriter.Flush();
                    break;

                case "AgregarCita":
                    Socket<string> peticionACt = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    string[] datosCita = peticionACt.Entidad.Split(',');
                    Cita cita = new Cita(int.Parse(datosCita[0]), Convert.ToDateTime(datosCita[1]), new TipoConsulta(int.Parse(datosCita[2]), "", ' '), new Cliente(int.Parse(datosCita[3]), "", "", "", ' ', new DateTime()), new Doctor(int.Parse(datosCita[4]), "", "", "", ' '));
                    metodos.AgregarCita(cita);
                    servidorStreamWriter.WriteLine(JsonConvert.SerializeObject(true));
                    servidorStreamWriter.Flush();
                    //textBox1.Text = "El cliente de ID: " + peticionACt.cita.getCliente.getIdentificacion + " ha registrado una citas";
                    break;

                default:
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                IPAddress local = IPAddress.Parse("127.0.0.1");
                tcpListener = new TcpListener(local, 14100);
                servidorIniciado = true;

                subprocesoEscuchaClientes = new Thread(new ThreadStart(EscucharClientes));
                subprocesoEscuchaClientes.Start();
                subprocesoEscuchaClientes.IsBackground = true;
                button1.Enabled = false; button3.Enabled = true;
                textBox1.Text = "Servidor iniciado... en (127.0.0.1, 14100)";
                textBox1.AppendText(Environment.NewLine);
            }
            catch (Exception)
            {
                MessageBox.Show("Error al iniciar el servidor");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Funcionalidades F = new Funcionalidades(this);
            F.Visible = true;
            this.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            servidorIniciado = false;
            tcpListener.Stop();
            button1.Enabled = true; button3.Enabled = false;
            textBox1.Text = "Servidor apagado";
            textBox1.AppendText(Environment.NewLine);
        }
    }
}
