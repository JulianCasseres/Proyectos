﻿using Entidades;
using Metodos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class RegistrarCitas : Form
    {
        Funcionalidades funcionalidades;
        MetodosBaseDatos metodos = new MetodosBaseDatos();
        List<TipoConsulta> listaTipos = new List<TipoConsulta>();
        List<Cliente> listaClientes = new List<Cliente>();
        List<Doctor> listaDoctores = new List<Doctor>();

        TipoConsulta tipo = null;
        Cliente cliente = null;
        Doctor doctor = null;

        public RegistrarCitas(Funcionalidades funcionalidades)
        {
            InitializeComponent();
            this.funcionalidades = funcionalidades;

            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;

            listaTipos = metodos.TiposConsultaRegistradas();
            listaClientes = metodos.ClientesRegistrados();
            listaDoctores = metodos.DoctoresRegistrados();

            Mostrar_TiposConsulta();
            Mostrar_Clientes();
            Mostrar_Doctores();
        }

        private void Mostrar_TiposConsulta()
        {
            int j = 0;
            for (int i = 0; i < listaTipos.Count; i++)
            {
                if (listaTipos.ElementAt(i).getEstado.Equals('A'))
                {
                    dataGridView1.Rows.Add();
                    dataGridView1.Rows[j].Cells[0].Value = listaTipos.ElementAt(i).getNumero;
                    dataGridView1.Rows[j].Cells[1].Value = listaTipos.ElementAt(i).getDescripcion;
                    j++;
                }
            }
        }

        private void Mostrar_Clientes()
        {
            for (int i = 0; i < listaClientes.Count; i++)
            {
                dataGridView2.Rows.Add();
                dataGridView2.Rows[i].Cells[0].Value = listaClientes.ElementAt(i).getIdentificacion;
                dataGridView2.Rows[i].Cells[1].Value = listaClientes.ElementAt(i).getNombre;
                dataGridView2.Rows[i].Cells[2].Value = listaClientes.ElementAt(i).getApellido1;
            }
        }

        private void Mostrar_Doctores()
        {
            int j = 0;
            for (int i = 0; i < listaDoctores.Count; i++)
            {
                if (listaDoctores.ElementAt(i).getEstado.Equals('A'))
                {
                    dataGridView3.Rows.Add();
                    dataGridView3.Rows[j].Cells[0].Value = listaDoctores.ElementAt(i).getIdentificacion;
                    dataGridView3.Rows[j].Cells[1].Value = listaDoctores.ElementAt(i).getNombre;
                    dataGridView3.Rows[j].Cells[2].Value = listaDoctores.ElementAt(i).getApellido1;
                    j++;
                }
            }
        }

        private bool validar_datos(String fecha)
        {
            DateTime fechaConvertida;
            if (!DateTime.TryParseExact(fecha, "d/M/yyyy", null, DateTimeStyles.None, out fechaConvertida))
            {
                return false;
            }
            return true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tipo == null || cliente == null || doctor == null)
            {
                MessageBox.Show("Seleccione: (Tipo Consulta, Cliente y Doctor) ");
            }
            else
            {
                try
                {
                    int numero = int.Parse(textBox1.Text);
                    int horas = int.Parse(comboBox1.SelectedItem.ToString());
                    int minutos = int.Parse(comboBox2.SelectedItem.ToString());
                    String fecha = textBox2.Text;

                    if (validar_datos(fecha))
                    {
                        DateTime fc = DateTime.ParseExact(fecha, "d/M/yyyy", null);
                        new DateTime(fc.Year, fc.Month, fc.Day, horas, minutos, 0);
                        if (metodos.VerificarCita(numero, fc))
                        {
                            Cita cita = new Cita(numero, new DateTime(fc.Year, fc.Month, fc.Day, horas, minutos, 0), tipo, cliente, doctor);
                            metodos.AgregarCita(cita);
                            MessageBox.Show("Cita Registrada Correctamente");
                        }
                        else
                        {
                            MessageBox.Show("No Hay Disponibilidad para esa Fecha y esa Hora ó la Cita ya se ha registrado");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Verifique que la fecha esté en formato d/M/yyyy");
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Error en el campo numero cita");
                }
                textBox1.Text = ""; textBox2.Text = "";
                comboBox1.SelectedIndex = 0; comboBox2.SelectedIndex = 0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            funcionalidades.Visible = true;
            this.Visible = false;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int fila = e.RowIndex;
            if (fila != -1)
            {
                int numero = int.Parse(dataGridView1.Rows[fila].Cells[0].Value.ToString());
                tipo = metodos.VerificarTipoConsulta(numero);
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int fila = e.RowIndex;
            if (fila != -1)
            {
                int identificacion = int.Parse(dataGridView2.Rows[fila].Cells[0].Value.ToString());
                cliente = metodos.VerificarCliente(identificacion);
            }
        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int fila = e.RowIndex;
            if (fila != -1)
            {
                int identificacion = int.Parse(dataGridView3.Rows[fila].Cells[0].Value.ToString());
                doctor = metodos.VerificarDoctor(identificacion);
            }
        }
    }
}
