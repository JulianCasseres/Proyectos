﻿using Entidades;
using Metodos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class CitasPorCliente : Form
    {
        Funcionalidades funcionalidades;
        MetodosBaseDatos metodos = new MetodosBaseDatos();
        List<Cliente> listaClientes = new List<Cliente>();
        List<String> CitasCliente = new List<String>();

        public CitasPorCliente(Funcionalidades funcionalidades)
        {
            InitializeComponent();
            this.funcionalidades = funcionalidades;
            listaClientes = metodos.ClientesRegistrados();
            Mostrar_Clientes();
        }

        private void Mostrar_Clientes()
        {
            for (int i = 0; i < listaClientes.Count; i++)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[i].Cells[0].Value = listaClientes.ElementAt(i).getIdentificacion;
                dataGridView1.Rows[i].Cells[1].Value = listaClientes.ElementAt(i).getNombre;
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int fila = e.RowIndex;
            if (fila != -1)
            {
                int IdCliente = int.Parse(dataGridView1.Rows[fila].Cells[0].Value.ToString());
                CitasCliente = metodos.CitasCliente(IdCliente);

                dataGridView2.Rows.Clear();
                if (CitasCliente.Count == 0)
                {
                    MessageBox.Show("NO Hay Citas Relacionadas al Cliente");
                }
                else
                {
                    for (int i = 0; i < CitasCliente.Count; i++)
                    {
                        String[] datos = CitasCliente.ElementAt(i).Split(',');
                        dataGridView2.Rows.Add();
                        dataGridView2.Rows[i].Cells[0].Value = datos[0];
                        dataGridView2.Rows[i].Cells[1].Value = datos[1];
                        dataGridView2.Rows[i].Cells[2].Value = datos[2];
                        dataGridView2.Rows[i].Cells[3].Value = datos[3];
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            funcionalidades.Visible = true;
            this.Visible = false;
        }
    }
}
