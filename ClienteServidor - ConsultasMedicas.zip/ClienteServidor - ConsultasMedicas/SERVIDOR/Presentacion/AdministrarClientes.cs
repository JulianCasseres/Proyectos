﻿using Entidades;
using Metodos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class AdministrarClientes : Form
    {
        Funcionalidades funcionalidades;
        MetodosBaseDatos metodos = new MetodosBaseDatos();
        List<Cliente> listaClientes = new List<Cliente>();

        public AdministrarClientes(Funcionalidades funcionalidades)
        {
            InitializeComponent();
            this.funcionalidades = funcionalidades;
            listaClientes = metodos.ClientesRegistrados();

            comboBox1.SelectedIndex = 0;
            button2.Enabled = false; button3.Enabled = false;
            Mostrar_Clientes();
        }

        private bool validar_datos(String nombre, String apellido1, String apellido2, String fecha, int index)
        {
            if (nombre.Length == 0 || apellido1.Length == 0 || apellido2.Length == 0 || index == 0)
            {
                return false;
            }

            DateTime fechaConvertida;
            if (!DateTime.TryParseExact(fecha, "d/M/yyyy", null, DateTimeStyles.None, out fechaConvertida))
            {
                return false;
            }
            return true;
        }

        private void Mostrar_Clientes()
        {
            dataGridView1.DataSource = metodos.ClientesRegistrados();
            dataGridView1.Columns["getNombre"].Width = 150;
            dataGridView1.Columns["getApellido1"].Width = 150;
            dataGridView1.Columns["getApellido2"].Width = 150;
            dataGridView1.Columns["getFecha"].Width = 120;
            dataGridView1.Columns["getGenero"].Width = 80;
            dataGridView1.Columns["getIdentificacion"].HeaderText = "ID";
            dataGridView1.Columns["getNombre"].HeaderText = "Nombre";
            dataGridView1.Columns["getApellido1"].HeaderText = "Apellido1";
            dataGridView1.Columns["getApellido2"].HeaderText = "Apellido2";
            dataGridView1.Columns["getFecha"].HeaderText = "Nacimiento";
            dataGridView1.Columns["getGenero"].HeaderText = "Genero";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int identificacion = int.Parse(textBox1.Text);
                String nombre = textBox2.Text;
                String apellido1 = textBox3.Text;
                String apellido2 = textBox4.Text;
                String fecha = textBox5.Text;

                if (metodos.VerificarCliente(identificacion) == null)
                {
                    if (validar_datos(nombre, apellido1, apellido2, fecha, comboBox1.SelectedIndex))
                    {
                        if (comboBox1.SelectedIndex == 1)
                        {
                            Cliente cliente = new Cliente(identificacion, nombre, apellido1, apellido2, 'F', DateTime.Parse(fecha));
                            metodos.AgregarCliente(cliente);
                        }
                        else if (comboBox1.SelectedIndex == 2)
                        {
                            Cliente cliente = new Cliente(identificacion, nombre, apellido1, apellido2, 'M', DateTime.Parse(fecha));
                            metodos.AgregarCliente(cliente);
                        }
                        else if (comboBox1.SelectedIndex == 3)
                        {
                            Cliente cliente = new Cliente(identificacion, nombre, apellido1, apellido2, 'N', DateTime.Parse(fecha));
                            metodos.AgregarCliente(cliente);
                        }
                        MessageBox.Show("Cliente Registrado Correctamente");
                        dataGridView1.Enabled = true;
                        Mostrar_Clientes();
                    }
                    else
                    {
                        MessageBox.Show("Verifique la informacion ingresada");
                    }
                }
                else
                {
                    MessageBox.Show("Cliente ya registrado");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Error en el campo ID");
            }
            textBox1.Text = ""; textBox2.Text = ""; textBox3.Text = "";
            textBox4.Text = ""; textBox5.Text = ""; comboBox1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int identificacion = int.Parse(textBox1.Text);
            String nombre = textBox2.Text;
            String apellido1 = textBox3.Text;
            String apellido2 = textBox4.Text;
            String fecha = textBox5.Text;

            DateTime fechaConvertida;
            if (comboBox1.SelectedIndex == 0 || !DateTime.TryParseExact(fecha, "d/M/yyyy", null, DateTimeStyles.None, out fechaConvertida))
            {
                MessageBox.Show("Hubo un Error, NO se realizaron los cambios");
            }
            else
            {
                if (comboBox1.SelectedIndex == 1)
                {
                    Cliente cliente = new Cliente(identificacion, nombre, apellido1, apellido2, 'F', fechaConvertida);
                    metodos.ModificarCliente(cliente);
                }
                else if (comboBox1.SelectedIndex == 2)
                {
                    Cliente cliente = new Cliente(identificacion, nombre, apellido1, apellido2, 'M', fechaConvertida);
                    metodos.ModificarCliente(cliente);
                }
                else if (comboBox1.SelectedIndex == 3)
                {
                    Cliente cliente = new Cliente(identificacion, nombre, apellido1, apellido2, 'N', fechaConvertida);
                    metodos.ModificarCliente(cliente);
                }
                MessageBox.Show("Cliente Modificado Correctamente");
                Mostrar_Clientes();
            }

            textBox1.Text = ""; textBox2.Text = "";
            textBox3.Text = ""; textBox4.Text = "";
            textBox5.Text = ""; comboBox1.SelectedIndex = 0;
            textBox1.Enabled = true; textBox2.Enabled = true;
            textBox3.Enabled = true; textBox4.Enabled = true;
            button1.Enabled = true; button2.Enabled = false; button3.Enabled = false;
            dataGridView1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = ""; textBox2.Text = "";
            textBox3.Text = ""; textBox4.Text = "";
            textBox5.Text = ""; comboBox1.SelectedIndex = 0;
            textBox1.Enabled = true; textBox2.Enabled = true;
            textBox3.Enabled = true; textBox4.Enabled = true;
            button1.Enabled = true; button2.Enabled = false; button3.Enabled = false;
            dataGridView1.Enabled = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            funcionalidades.Visible = true;
            this.Visible = false;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int fila = e.RowIndex;
            if (fila != -1)
            {
                button1.Enabled = false; button2.Enabled = true; button3.Enabled = true; dataGridView1.Enabled = false;
                textBox1.Text = dataGridView1.Rows[fila].Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.Rows[fila].Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.Rows[fila].Cells[2].Value.ToString();
                textBox4.Text = dataGridView1.Rows[fila].Cells[3].Value.ToString();
                String[] fecha = dataGridView1.Rows[fila].Cells[5].Value.ToString().Split(' ');
                textBox5.Text = fecha[0];
                textBox1.Enabled = false; textBox2.Enabled = false;
                textBox3.Enabled = false; textBox4.Enabled = false;
            }
        }
    }
}
