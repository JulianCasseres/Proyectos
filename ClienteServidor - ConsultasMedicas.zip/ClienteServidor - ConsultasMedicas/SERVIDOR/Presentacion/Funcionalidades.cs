﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class Funcionalidades : Form
    {
        ControlServidor control;

        public Funcionalidades(ControlServidor control)
        {
            InitializeComponent();
            this.control = control;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdministrarTiposConsultas ATC = new AdministrarTiposConsultas(this);
            ATC.Visible = true;
            this.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdministrarClientes AC = new AdministrarClientes(this);
            AC.Visible = true;
            this.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdministarDoctores AD = new AdministarDoctores(this);
            AD.Visible = true;
            this.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            RegistrarCitas RC = new RegistrarCitas(this);
            RC.Visible = true;
            this.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CitasPorFecha CF = new CitasPorFecha(this);
            CF.Visible = true;
            this.Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            CitasPorCliente CC = new CitasPorCliente(this);
            CC.Visible = true;
            this.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            CitasPorDoctor CD = new CitasPorDoctor(this);
            CD.Visible = true;
            this.Visible = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            control.Visible = true;
            this.Visible = false;
        }
    }
}
