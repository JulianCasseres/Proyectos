﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Entidades;
using System.Configuration;
using System.Windows.Forms;

namespace Metodos
{
    public class MetodosBaseDatos
    {
        private string cadenaConexion;
        static List<string> Conectados = new List<string>();
        static SemaphoreSlim semaforoAccesoBaseDatos = new SemaphoreSlim(1);

        public MetodosBaseDatos()
        {
            cadenaConexion = ConfigurationManager.ConnectionStrings["DENTUNED"].ConnectionString;
        }

        public List<string> ClientesConectados()
        {
            try
            {
                Console.WriteLine("Adquiriendo semáforo...");
                semaforoAccesoBaseDatos.Wait();
                Console.WriteLine("Semáforo adquirido.");
                return Conectados;
            }
            finally
            {
                Console.WriteLine("Liberando semáforo...");
                semaforoAccesoBaseDatos.Release();
                Console.WriteLine("Semáforo liberado.");
            }
        }

        public void ConectarCliente(string IdCliente)
        {
            Conectados.Add(IdCliente);
        }

        public void DesconectarCliente(string IdCliente)
        {
            Conectados.Remove(IdCliente);
        }


        #region MetodosTipoConsulta
        public List<TipoConsulta> TiposConsultaRegistradas()
        {
            List<TipoConsulta> listaTipos = new List<TipoConsulta>();
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;
            SqlDataReader reader;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "SELECT * FROM Tipo_Consulta";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                conexion.Open();
                reader = comando.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        listaTipos.Add(new TipoConsulta(Convert.ToInt32(reader.GetDecimal(0)), reader.GetString(1), Convert.ToChar(reader.GetString(2))));
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al obtener los tipos de consulta registradas");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
            return listaTipos;
        }

        public void AgregarTipoConsulta(TipoConsulta tipoConsulta)
        {
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "INSERT INTO Tipo_Consulta (numero, descripcion, estado)" +
                                    " VALUES (@numero, @descripcion, @estado)";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@numero", tipoConsulta.getNumero);
                comando.Parameters.AddWithValue("@descripcion", tipoConsulta.getDescripcion);
                comando.Parameters.AddWithValue("@estado", tipoConsulta.getEstado);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception)
            {
                MessageBox.Show("Error al agregar el tipo de consulta");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }

        public TipoConsulta VerificarTipoConsulta(int numero)
        {
            TipoConsulta tipo = null;
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;
            SqlDataReader reader;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "SELECT numero, descripcion, estado" +
                            " FROM Tipo_Consulta" +
                            " WHERE numero = @numero";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@numero", numero);
                conexion.Open();
                reader = comando.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        tipo = new TipoConsulta(Convert.ToInt32(reader.GetDecimal(0)), reader.GetString(1), Convert.ToChar(reader.GetString(2)));
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al obtener verificar el tipo de consulta");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
            return tipo;
        }

        public void ModificarTipoConsulta(TipoConsulta tipo)
        {
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "UPDATE Tipo_Consulta set numero="+tipo.getNumero+",descripcion='"+tipo.getDescripcion+"',estado='"+tipo.getEstado+"' WHERE numero = @numero";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@numero", tipo.getNumero);
                conexion.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception)
            {
                MessageBox.Show("Error al modifcar el tipo de consulta");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }
        #endregion

        #region MetodosDoctores
        public List<Doctor> DoctoresRegistrados()
        {
            List<Doctor> listaDoctores = new List<Doctor>();
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;
            SqlDataReader reader;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "SELECT * FROM Doctor";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                conexion.Open();
                reader = comando.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        listaDoctores.Add(new Doctor(Convert.ToInt32(reader.GetDecimal(0)), reader.GetString(1), reader.GetString(2), reader.GetString(3), Convert.ToChar(reader.GetString(4))));
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al obtener los doctores registrados");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
            return listaDoctores;
        }

        public void AgregarDoctor(Doctor doctor)
        {
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "INSERT INTO Doctor (identificacion, nombre, apellido1, apellido2, estado)" +
                                    " VALUES (@identificacion, @nombre, @apellido1, @apellido2, @estado)";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@identificacion", doctor.getIdentificacion);
                comando.Parameters.AddWithValue("@nombre", doctor.getNombre);
                comando.Parameters.AddWithValue("@apellido1", doctor.getApellido1);
                comando.Parameters.AddWithValue("@apellido2", doctor.getApellido2);
                comando.Parameters.AddWithValue("@estado", doctor.getEstado);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception)
            {
                MessageBox.Show("Error al agregar el doctor");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }

        public Doctor VerificarDoctor(int identificacion)
        {
            Doctor doctor = null;
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;
            SqlDataReader reader;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "SELECT identificacion, nombre, apellido1, apellido2, estado" +
                            " FROM Doctor" +
                            " WHERE identificacion = @identificacion";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@identificacion", identificacion);
                conexion.Open();
                reader = comando.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        doctor = new Doctor(Convert.ToInt32(reader.GetDecimal(0)), reader.GetString(1), reader.GetString(2), reader.GetString(3), Convert.ToChar(reader.GetString(4)));
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al verificar el doctor");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
            return doctor;
        }

        public void ModificarDoctor(Doctor doctor)
        {
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "UPDATE Doctor set identificacion=" + doctor.getIdentificacion + ",nombre='" + doctor.getNombre + "',apellido1='" + doctor.getApellido1 + "',apellido2='" + doctor.getApellido2 + "',estado='" + doctor.getEstado + "' WHERE identificacion = @identificacion";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@identificacion", doctor.getIdentificacion);
                conexion.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception)
            {
                MessageBox.Show("Error al modificar el doctor");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }
        #endregion

        #region MetodosClientes
        public List<Cliente> ClientesRegistrados()
        {
            List<Cliente> listaClientes = new List<Cliente>();
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;
            SqlDataReader reader;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "SELECT * FROM Cliente";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                conexion.Open();
                reader = comando.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        listaClientes.Add(new Cliente(Convert.ToInt32(reader.GetDecimal(0)), reader.GetString(1), reader.GetString(2), reader.GetString(3), Convert.ToChar(reader.GetString(5)), reader.GetDateTime(4)));
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al obtener los clientes registrados");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
            return listaClientes;
        }

        public void AgregarCliente(Cliente cliente)
        {
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "INSERT INTO Cliente (identificacion, nombre, apellido1, apellido2, fec_nacimiento, genero)" +
                                    " VALUES (@identificacion, @nombre, @apellido1, @apellido2, @fec_nacimiento, @genero)";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@identificacion", cliente.getIdentificacion);
                comando.Parameters.AddWithValue("@nombre", cliente.getNombre);
                comando.Parameters.AddWithValue("@apellido1", cliente.getApellido1);
                comando.Parameters.AddWithValue("@apellido2", cliente.getApellido2);
                comando.Parameters.AddWithValue("@fec_nacimiento", cliente.getFecha);
                comando.Parameters.AddWithValue("@genero", cliente.getGenero);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception)
            {
                MessageBox.Show("Error al agregar el cliente");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }

        public Cliente VerificarCliente(int identificacion)
        {
            Cliente cliente = null;
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;
            SqlDataReader reader;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "SELECT identificacion, nombre, apellido1, apellido2, fec_nacimiento, genero" +
                            " FROM Cliente" +
                            " WHERE identificacion = @identificacion";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@identificacion", identificacion);
                conexion.Open();
                reader = comando.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cliente = new Cliente(Convert.ToInt32(reader.GetDecimal(0)), reader.GetString(1), reader.GetString(2), reader.GetString(3), Convert.ToChar(reader.GetString(5)), reader.GetDateTime(4));
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al verificar el cliente");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
            return cliente;
        }

        public void ModificarCliente(Cliente cliente)
        {
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "UPDATE Cliente set identificacion=" + cliente.getIdentificacion + ",nombre='" + cliente.getNombre + "',apellido1='" + cliente.getApellido1 + "',apellido2='" + cliente.getApellido2 + "' WHERE identificacion = @identificacion";
                sentencia = "UPDATE Cliente set genero = @genero WHERE identificacion = @identificacion";
                sentencia = "UPDATE Cliente set fec_nacimiento = @fecha WHERE identificacion = @identificacion";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@identificacion", cliente.getIdentificacion);
                comando.Parameters.AddWithValue("@genero", cliente.getGenero);
                comando.Parameters.AddWithValue("@fecha", cliente.getFecha);
                conexion.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception)
            {
                MessageBox.Show("Error al modificar el cliente");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }
        #endregion

        #region MetodosCitas
        public void AgregarCita(Cita cita)
        {
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;

            try
            {
                conexion = new SqlConnection(cadenaConexion);

                sentencia = "INSERT INTO Cita (numero, fec_hor_cita, cod_tip_consulta, id_cliente, id_doctor)" +
                                    " VALUES (@numero, @fec_hor_cita, @cod_tip_consulta, @id_cliente, @id_doctor)";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@numero", cita.getNumero);
                comando.Parameters.AddWithValue("@fec_hor_cita", cita.getFechayHora);
                comando.Parameters.AddWithValue("@cod_tip_consulta", cita.getTipoconsulta.getNumero);
                comando.Parameters.AddWithValue("@id_cliente", cita.getCliente.getIdentificacion);
                comando.Parameters.AddWithValue("@id_doctor", cita.getDoctor.getIdentificacion);

                conexion.Open();
                comando.ExecuteNonQuery();
            }
            catch (Exception)
            {
                MessageBox.Show("Error al agregar la cita");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
        }

        public bool VerificarCita(int numero, DateTime FechayHora)
        {
            bool estado = true;
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;
            SqlDataReader reader;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "SELECT numero, fec_hor_cita, cod_tip_consulta, id_cliente, id_doctor" +
                            " FROM Cita" +
                            " WHERE numero = @numero OR fec_hor_cita = @fec_hor_cita";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@numero", numero);
                comando.Parameters.AddWithValue("@fec_hor_cita", FechayHora);
                conexion.Open();
                reader = comando.ExecuteReader();

                if (reader.HasRows)
                {
                    estado = false;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al verificar la cita");
                estado = false;
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
            return estado;
        }

        #endregion

        #region MetodosReportes
        public List<String> CitasFecha(String fecha)
        {
            List<String> datos = new List<String>();
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;
            SqlDataReader reader;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "SELECT * FROM Cita";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                conexion.Open();
                reader = comando.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        if(reader.GetDateTime(1).ToShortDateString().Equals(fecha))
                        {
                            datos.Add(reader.GetDecimal(0).ToString() + ","
                                + reader.GetDateTime(1).ToShortDateString() + " " + reader.GetDateTime(1).ToShortTimeString() + ","
                                + reader.GetDecimal(2) + ","
                                + reader.GetDecimal(3) + ","
                                + reader.GetDecimal(4));
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al obtener las citas por fecha");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
            return datos;
        }

        public List<String> CitasDoctor(int IdDoctor)
        {
            List<String> datos = new List<String>();
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;
            SqlDataReader reader;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "SELECT ci.numero, ci.fec_hor_cita, tc.descripcion, cl.nombre, cl.apellido1, cl.apellido2 " +
                            "FROM Cita ci " +
                            "INNER JOIN Cliente cl " +
                            "ON ci.id_cliente = cl.identificacion " +
                            "INNER JOIN Tipo_Consulta tc " +
                            "ON ci.cod_tip_consulta = tc.numero " +
                            "WHERE ci.id_doctor = @id_doctor";
                
                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@id_doctor", IdDoctor);
                conexion.Open();
                reader = comando.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        datos.Add(reader.GetDecimal(0).ToString() + ","
                                + reader.GetDateTime(1).ToShortDateString() + " " + reader.GetDateTime(1).ToShortTimeString() + ","
                                + reader.GetString(2) + ","
                                + reader.GetString(3) + " " + reader.GetString(4) + " " + reader.GetString(5));
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al obtener las citas por doctor");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
            return datos;
        }

        public List<String> CitasCliente(int IdCliente)
        {
            List<String> datos = new List<String>();
            SqlConnection conexion = null;
            SqlCommand comando = new SqlCommand();
            string sentencia;
            SqlDataReader reader;

            try
            {
                conexion = new SqlConnection(cadenaConexion);
                sentencia = "SELECT ci.numero, ci.fec_hor_cita, tc.descripcion, dt.nombre, dt.apellido1, dt.apellido2 " +
                            "FROM Cita ci " +
                            "INNER JOIN Doctor dt " +
                            "ON ci.id_doctor = dt.identificacion " +
                            "INNER JOIN Tipo_Consulta tc " +
                            "ON ci.cod_tip_consulta = tc.numero " +
                            "WHERE ci.id_cliente = @id_cliente";

                comando.CommandType = CommandType.Text;
                comando.CommandText = sentencia;
                comando.Connection = conexion;
                comando.Parameters.AddWithValue("@id_cliente", IdCliente);
                conexion.Open();
                reader = comando.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        datos.Add(reader.GetDecimal(0).ToString() + ","
                                + reader.GetDateTime(1).ToShortDateString() + " " + reader.GetDateTime(1).ToShortTimeString() + ","
                                + reader.GetString(2) + ","
                                + reader.GetString(3) + " " + reader.GetString(4) + " " + reader.GetString(5));
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al obtener las citas por cliente");
            }
            finally
            {
                if (conexion != null && conexion.State == ConnectionState.Open)
                {
                    conexion.Close();
                }
            }
            return datos;
        }
        #endregion
    }
}
