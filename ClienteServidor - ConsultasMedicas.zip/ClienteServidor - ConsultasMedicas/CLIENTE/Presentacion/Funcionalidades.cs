﻿using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class Funcionalidades : Form
    {
        ControlCliente control;
        string datos;

        public Funcionalidades(string datos, ControlCliente control)
        {
            InitializeComponent();
            this.control = control;
            this.datos = datos;
            MostrarDatos();
        }

        private void MostrarDatos()
        {
            string[] datosCliente = datos.Split(',');
            label2.Text = "Identificacion: " + datosCliente[0];
            label3.Text = "Nombre: " + datosCliente[1];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RealizarCitas RC = new RealizarCitas(this, datos);
            RC.Visible = true;
            this.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MisCitas MC = new MisCitas(this, datos);
            MC.Visible = true;
            this.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            control.Visible = true;
            this.Visible = false;
        }
    }
}
