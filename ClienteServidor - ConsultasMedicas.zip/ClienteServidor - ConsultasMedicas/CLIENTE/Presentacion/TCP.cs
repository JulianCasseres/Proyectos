﻿using Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace Presentacion
{
    public class TCP
    {
        private static IPAddress ipServidor;
        private static TcpClient cliente;
        private static IPEndPoint serverEndPoint;
        private static StreamWriter clienteStreamWriter;
        private static StreamReader clienteStreamReader;

        public TCP()
        {

        }

        public static bool ConectarCliente(string IdCliente)
        {
            try
            {
                ipServidor = IPAddress.Parse("127.0.0.1");
                cliente = new TcpClient();
                serverEndPoint = new IPEndPoint(ipServidor, 14100);
                cliente.Connect(serverEndPoint);
                Socket<string> mensajeConectar = new Socket<string> { Metodo = "ConectarCliente", Entidad = IdCliente };
                clienteStreamReader = new StreamReader(cliente.GetStream());
                clienteStreamWriter = new StreamWriter(cliente.GetStream());
                clienteStreamWriter.AutoFlush = true;
                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensajeConectar));
            }
            catch (SocketException)
            {
                return false;
            }
            return true;
        }

        public static void DesconectarCliente(string IdCliente)
        {
            Socket<string> mensaje = new Socket<string> { Metodo = "DesconectarCliente", Entidad = IdCliente };
            clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensaje));
            clienteStreamWriter.Flush();
            cliente.Close();
        }

        public static List<string> ClientesConectados()
        {
            List<string> listaConectados = new List<string>();
            Socket<string> mensaje = new Socket<string> { Metodo = "ClientesConectados" };
            clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensaje));
            clienteStreamWriter.Flush();
            var respuesta = clienteStreamReader.ReadLine();
            listaConectados = JsonConvert.DeserializeObject<List<string>>(respuesta);
            return listaConectados;
        }

        public static string VerificarCliente(string IdCliente)
        {
            string datos;
            Socket<string> mensaje = new Socket<string> { Metodo = "VerificarCliente", Entidad = IdCliente };
            clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensaje));
            clienteStreamWriter.Flush();
            var respuesta = clienteStreamReader.ReadLine();
            datos = JsonConvert.DeserializeObject<string>(respuesta);
            return datos;
        }

        public static string VerificarTipoConsulta(string IdTipo)
        {
            string datos;
            Socket<string> mensaje = new Socket<string> { Metodo = "VerificarTipoConsulta", Entidad = IdTipo };
            clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensaje));
            clienteStreamWriter.Flush();
            var respuesta = clienteStreamReader.ReadLine();
            datos = JsonConvert.DeserializeObject<string>(respuesta);
            return datos;
        }

        public static string VerificarDoctor(string IdDoctor)
        {
            string datos;
            Socket<string> mensaje = new Socket<string> { Metodo = "VerificarDoctor", Entidad = IdDoctor };
            clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensaje));
            clienteStreamWriter.Flush();
            var respuesta = clienteStreamReader.ReadLine();
            datos = JsonConvert.DeserializeObject<string>(respuesta);
            return datos;
        }

        public static List<string> TiposConsultaRegistradas()
        {
            List<string> listaTipos = new List<string>();
            Socket<string> mensaje = new Socket<string> { Metodo = "TiposConsultasRegistradas" };
            clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensaje));
            clienteStreamWriter.Flush();
            var respuesta = clienteStreamReader.ReadLine();
            listaTipos = JsonConvert.DeserializeObject<List<string>>(respuesta);
            return listaTipos;
        }

        public static List<string> DoctoresRegistrados()
        {
            List<string> listaDoctores = new List<string>();
            Socket<string> mensaje = new Socket<string> { Metodo = "DoctoresRegistrados" };
            clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensaje));
            clienteStreamWriter.Flush();
            var respuesta = clienteStreamReader.ReadLine();
            listaDoctores = JsonConvert.DeserializeObject<List<string>>(respuesta);
            return listaDoctores;
        }

        public static List<string> CitasCliente(string IdCliente)
        {
            List<string> citasCliente = new List<string>();
            Socket<string> mensaje = new Socket<string> { Metodo = "CitasCliente", Entidad = IdCliente };
            clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensaje));
            clienteStreamWriter.Flush();
            var respuesta = clienteStreamReader.ReadLine();
            citasCliente = JsonConvert.DeserializeObject<List<string>>(respuesta);
            return citasCliente;
        }

        public static bool VerificarCita(string datos)
        {
            Socket<string> mensaje = new Socket<string> { Metodo = "VerificarCita", Entidad = datos };
            clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensaje));
            clienteStreamWriter.Flush();
            var respuesta = clienteStreamReader.ReadLine();
            return JsonConvert.DeserializeObject<bool>(respuesta);
        }

        public static bool AgregarCita(string datos)
        {
            Socket<string> mensaje = new Socket<string> { Metodo = "AgregarCita", Entidad = datos };
            clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensaje));
            clienteStreamWriter.Flush();
            var respuesta = clienteStreamReader.ReadLine();
            return JsonConvert.DeserializeObject<bool>(respuesta);
        }
    }
}
