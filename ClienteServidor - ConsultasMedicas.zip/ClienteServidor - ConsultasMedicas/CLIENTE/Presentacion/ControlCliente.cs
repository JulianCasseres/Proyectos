﻿using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class ControlCliente : Form
    {
        bool estadoConexion = false;

        public ControlCliente()
        {
            InitializeComponent();
            button2.Enabled = false;
        }

        bool EstadoConexion(string identificacion)
        {
            int cont = 0;
            foreach (string id in TCP.ClientesConectados())
            {
                if (id.Equals(identificacion))
                {
                    cont++;
                }
            }
            if (cont > 1)
            {
                return true;
            }
            return false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(textBox1.Text))
                {
                    if (TCP.ConectarCliente(textBox1.Text))
                    {
                        string datos = null;
                        datos = TCP.VerificarCliente(textBox1.Text);
                        estadoConexion = true;

                        if (datos != null)
                        {
                            if (EstadoConexion(textBox1.Text))
                            {
                                MessageBox.Show("Cliente ya conectado");
                            }
                            else
                            {
                                estadoConexion = true;
                                button1.Enabled = false; button2.Enabled = true;
                                Funcionalidades F = new Funcionalidades(datos, this);
                                F.Visible = true;
                                this.Visible = false;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Identificación no registrada en la base de datos");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Verifique que el servidor esté escuchando clientes");
                    }
                }
                else
                {
                    MessageBox.Show("Debe ingresar su identificacion");
                }
            }
            catch (InvalidCastException)
            {
                MessageBox.Show("Ha ocurrido un error al convertir el objeto seleccionado");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ha ocurrido un error al realizar la acción solicitada, revise el estado del servidor" + ex);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (estadoConexion)
            {
                TCP.DesconectarCliente(textBox1.Text);
                estadoConexion = false;
                button1.Enabled = true; button2.Enabled = false;
            }
        }
    }
}
