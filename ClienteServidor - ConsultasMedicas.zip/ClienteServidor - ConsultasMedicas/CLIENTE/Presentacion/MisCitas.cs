﻿using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class MisCitas : Form
    {
        Funcionalidades funcionalidades;
        List<string> CitasCliente = new List<string>();
        string datos;

        public MisCitas(Funcionalidades funcionalidades, string datos)
        {
            InitializeComponent();
            this.funcionalidades = funcionalidades;
            this.datos = datos;
            MostrarDatos();
            MostrarCitas(datos);
        }

        private void MostrarDatos()
        {
            string[] datosCliente = datos.Split(',');
            label9.Text = "Identificacion: " + datosCliente[0];
            label3.Text = "Nombre: " + datosCliente[1];
        }

        private void MostrarCitas(string datos)
        {
            try
            {
                string[] datosCliente = datos.Split(',');
                CitasCliente = TCP.CitasCliente(datosCliente[0]);
                dataGridView2.Rows.Clear();
                if (CitasCliente.Count == 0)
                {
                    MessageBox.Show("NO Hay Citas Relacionadas al Cliente");
                }
                else
                {
                    for (int i = 0; i < CitasCliente.Count; i++)
                    {
                        string[] datosCitas = CitasCliente.ElementAt(i).Split(',');
                        dataGridView2.Rows.Add();
                        dataGridView2.Rows[i].Cells[0].Value = datosCitas[0];
                        dataGridView2.Rows[i].Cells[1].Value = datosCitas[1];
                        dataGridView2.Rows[i].Cells[2].Value = datosCitas[2];
                        dataGridView2.Rows[i].Cells[3].Value = datosCitas[3];
                    }
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Error al cargar las citas por cliente");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            funcionalidades.Visible = true;
            this.Visible = false;
        }
    }
}
