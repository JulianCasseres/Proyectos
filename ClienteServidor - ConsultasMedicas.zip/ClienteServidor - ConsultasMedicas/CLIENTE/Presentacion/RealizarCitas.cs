﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace Presentacion
{
    public partial class RealizarCitas : Form
    {
        Funcionalidades funcionalidades;
        List<string> listaTipos = new List<string>();
        List<string> listaDoctores = new List<string>();

        string datos;
        TipoConsulta tipo = null;
        Doctor doctor = null;

        public RealizarCitas(Funcionalidades funcionalidades, string datos)
        {
            InitializeComponent();
            this.funcionalidades = funcionalidades;
            this.datos = datos;
            MostrarDatos();

            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;

            try
            {
                listaTipos = TCP.TiposConsultaRegistradas();
                listaDoctores = TCP.DoctoresRegistrados();
            }
            catch (Exception)
            {
                MessageBox.Show("Error al cargar la informacion de los tipos de consulta o los doctores");
            }

            Mostrar_TiposConsulta();
            Mostrar_Doctores();
        }

        private void MostrarDatos()
        {
            string[] datosCliente = datos.Split(',');
            label9.Text = "Identificacion: " + datosCliente[0];
            label3.Text = "Nombre: " + datosCliente[1];
        }

        private void Mostrar_TiposConsulta()
        {
            int j = 0;
            for (int i = 0; i < listaTipos.Count; i++)
            {
                string[] datosTipo = listaTipos.ElementAt(i).Split(',');
                if (datosTipo[2].Equals("A"))
                {
                    dataGridView1.Rows.Add();
                    dataGridView1.Rows[j].Cells[0].Value = datosTipo[0];
                    dataGridView1.Rows[j].Cells[1].Value = datosTipo[1];
                    j++;
                }
            }
        }
        private void Mostrar_Doctores()
        {
            int j = 0;
            for (int i = 0; i < listaDoctores.Count; i++)
            {
                string[] datosTipo = listaDoctores.ElementAt(i).Split(',');
                if (datosTipo[4].Equals("A"))
                {
                    dataGridView3.Rows.Add();
                    dataGridView3.Rows[j].Cells[0].Value = datosTipo[0];
                    dataGridView3.Rows[j].Cells[1].Value = datosTipo[1];
                    dataGridView3.Rows[j].Cells[2].Value = datosTipo[2];
                    j++;
                }
            }
        }

        private bool validar_datos(String fecha)
        {
            DateTime fechaConvertida;
            if (!DateTime.TryParseExact(fecha, "d/M/yyyy", null, DateTimeStyles.None, out fechaConvertida))
            {
                return false;
            }
            return true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tipo == null || doctor == null)
            {
                MessageBox.Show("Seleccione: (Tipo Consulta y Doctor) ");
            }
            else
            {
                try
                {
                    int numero = int.Parse(textBox1.Text);
                    int horas = int.Parse(comboBox1.SelectedItem.ToString());
                    int minutos = int.Parse(comboBox2.SelectedItem.ToString());
                    String fecha = textBox2.Text;

                    if (validar_datos(fecha))
                    {
                        DateTime fc = DateTime.ParseExact(fecha, "d/M/yyyy", null);
                        new DateTime(fc.Year, fc.Month, fc.Day, horas, minutos, 0);

                        string[] datosCliente = datos.Split(',');
                        string parametros = textBox1.Text + "," + new DateTime(fc.Year, fc.Month, fc.Day, horas, minutos, 0) + "," + tipo.numero + "," + datosCliente[0] + "," + doctor.getIdentificacion;
                        bool verificacion = TCP.VerificarCita(parametros);
                        if (verificacion == true)
                        {
                            TCP.AgregarCita(parametros);
                            MessageBox.Show("Cita Registrada Correctamente");
                        }
                        else
                        {
                            MessageBox.Show("No Hay Disponibilidad para esa Fecha y esa Hora ó la Cita ya se ha registrado");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Verifique que la fecha esté en formato d/M/yyyy");
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Error en el campo numero cita");
                }
                textBox1.Text = ""; textBox2.Text = "";
                comboBox1.SelectedIndex = 0; comboBox2.SelectedIndex = 0;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            funcionalidades.Visible = true;
            this.Visible = false;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int fila = e.RowIndex;
            if (fila != -1)
            {
                string numero = dataGridView1.Rows[fila].Cells[0].Value.ToString();
                string datosRecibidos = TCP.VerificarTipoConsulta(numero);
                string[] datosTipo = datosRecibidos.Split(',');
                tipo = new TipoConsulta(int.Parse(datosTipo[0]), datosTipo[1], Convert.ToChar(datosTipo[2]));
            }
        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int fila = e.RowIndex;
            if (fila != -1)
            {
                string identificacion = dataGridView3.Rows[fila].Cells[0].Value.ToString();
                string datosRecibidos = TCP.VerificarDoctor(identificacion);
                string[] datosDoctor = datosRecibidos.Split(',');
                doctor = new Doctor(int.Parse(datosDoctor[0]), datosDoctor[1], datosDoctor[2], datosDoctor[3], Convert.ToChar(datosDoctor[4]));
            }
        }
    }
}
