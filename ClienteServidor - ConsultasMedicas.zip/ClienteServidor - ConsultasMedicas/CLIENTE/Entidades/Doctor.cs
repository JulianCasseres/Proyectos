﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Doctor
    {
        private int identificacion;
        private String nombre, apellido1, apellido2;
        private char estado;

        public Doctor(int identificacion, string nombre, string apellido1, string apellido2, char estado)
        {
            this.identificacion = identificacion;
            this.nombre = nombre;
            this.apellido1 = apellido1;
            this.apellido2 = apellido2;
            this.estado = estado;
        }

        public int getIdentificacion { get => identificacion; }
        public string getNombre { get => nombre; }
        public string getApellido1 { get => apellido1; }
        public string getApellido2 { get => apellido2; }
        public char getEstado { get => estado; }
    }
}
