﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    [Serializable]
    public class TipoConsulta
    {
        public int numero { get; set; }
        public String descripcion { get; set; }
        public char estado { get; set; }

        public TipoConsulta(int numero, string descripcion, char estado)
        {
            this.numero = numero;
            this.descripcion = descripcion;
            this.estado = estado;
        }

        public string toString { get => numero + "-" + descripcion + "-" + estado; }
    }
}
