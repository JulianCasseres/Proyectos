﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    [Serializable]
    public class Cita
    {
        private int numero;
        private DateTime fechayhora;
        private TipoConsulta tipoconsulta;
        private Cliente cliente;
        private Doctor doctor;

        public Cita(int numero, DateTime fechayhora, TipoConsulta tipoconsulta, Cliente cliente, Doctor doctor)
        {
            this.numero = numero;
            this.fechayhora = fechayhora;
            this.tipoconsulta = tipoconsulta;
            this.cliente = cliente;
            this.doctor = doctor;
        }

        public int getNumero { get => numero; }
        public DateTime getFechayHora { get => fechayhora; }
        public TipoConsulta getTipoconsulta { get => tipoconsulta; }
        public Cliente getCliente { get => cliente; }
        public Doctor getDoctor { get => doctor; }
    }
}
