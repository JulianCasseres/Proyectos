﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaEntidades;
using CapaPresentacion.Realizar_Consultar;

namespace CapaPresentacion
{
    public partial class Form1 : Form
    {
        Cliente cliente;

        public Form1()
        {
            InitializeComponent();
            comboBox1.Enabled = false;
            button2.Enabled = false;
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int identificacion = int.Parse(textBox1.Text);

                if (ProtocoloTCP.ConectarCliente(identificacion))
                {
                    cliente = ProtocoloTCP.ObtenerCliente(identificacion);
                    if (cliente != null)
                    {
                        comboBox1.Enabled = true;
                        button1.Enabled = false;
                        button2.Enabled = true;
                        textBox1.Enabled = false;
                        MessageBox.Show("Bienvenido");
                    }
                    else
                    {
                        MessageBox.Show("Cliente No encontrado en la base de datos");
                        button2_Click(sender, e);
                    }
                }
                else
                {
                    MessageBox.Show("El servidor esta apagado, espere a que se inicie para poder conectarse");
                }
            }
            catch(FormatException)
            {
                MessageBox.Show("Cliente No encontrado en la base de datos");
            }
            catch (Exception)
            {
                MessageBox.Show("Error al conectarse al servidor");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int identificacion = int.Parse(textBox1.Text);
            ProtocoloTCP.DesconectarCliente(identificacion);
            comboBox1.Enabled = false;
            button1.Enabled = true;
            button2.Enabled = false;
            textBox1.Text = "";
            textBox1.Enabled = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 1:
                    RealizarCita realiza = new RealizarCita(this, cliente);
                    realiza.Visible = true;
                    this.Visible = false;
                    break;

                case 2:
                    ConsultarCitas consulta = new ConsultarCitas(this, cliente);
                    consulta.Visible = true;
                    this.Visible = false;
                    break;

                default:
                    break;
            }
            comboBox1.SelectedIndex = 0;
        }
    }
}
