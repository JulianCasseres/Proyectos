﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using CapaEntidades;
using Newtonsoft.Json;
using System.Windows.Forms;
using System.Drawing;

namespace CapaPresentacion
{
    public class ProtocoloTCP
    {
        private static IPAddress ipServidor;
        private static TcpClient cliente;
        private static IPEndPoint serverEndPoint;
        private static StreamWriter clienteStreamWriter;
        private static StreamReader clienteStreamReader;

        public static bool ConectarCliente(int identificacion)
        {
            try
            {
                ipServidor = IPAddress.Parse("127.0.0.1");
                cliente = new TcpClient();
                serverEndPoint = new IPEndPoint(ipServidor, 14100);
                cliente.Connect(serverEndPoint);

                Socket<string> mensajeConectarCliente = new Socket<string>
                {
                    Metodo = "ConectarCliente",
                    Entidad = identificacion.ToString()
                };
                clienteStreamReader = new StreamReader(cliente.GetStream());
                clienteStreamWriter = new StreamWriter(cliente.GetStream());
                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensajeConectarCliente));
                clienteStreamWriter.Flush();
            }
            catch (SocketException)
            {
                return false;
            }
            return true;
        }

        public static void DesconectarCliente(int identificacion)
        {
            Socket<string> mensajeDesconectar = new Socket<string>
            {
                Metodo = "DesconectarCliente",
                Entidad = identificacion.ToString()
            };
            clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensajeDesconectar));
            clienteStreamWriter.Flush();
            cliente.Close();
        }

        public static Cliente ObtenerCliente(int identificacion)
        {
            Cliente cliente = null;

            try
            {
                Socket<string> mensajeObtenerCliente = new Socket<string>
                {
                    Metodo = "ObtenerCliente",
                    Entidad = identificacion.ToString()
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensajeObtenerCliente));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                cliente = JsonConvert.DeserializeObject<Cliente>(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el cliente especificado: " + ex.Message);
            }

            return cliente;
        }

        public static Doctor ObtenerDoctor(int identificacion)
        {
            Doctor doctor = null;

            try
            {
                Socket<string> mensajeObtenerDoctor = new Socket<string>
                {
                    Metodo = "ObtenerDoctor",
                    Entidad = identificacion.ToString()
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensajeObtenerDoctor));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                doctor = JsonConvert.DeserializeObject<Doctor>(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el doctor especificado: " + ex.Message);
            }

            return doctor;
        }

        public static TipoConsulta ObtenerTipoConsulta(int numero)
        {
            TipoConsulta tipo = null;

            try
            {
                Socket<string> mensajeObtenerTipoConsulta = new Socket<string>
                {
                    Metodo = "ObtenerTipoConsulta",
                    Entidad = numero.ToString()
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensajeObtenerTipoConsulta));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                tipo = JsonConvert.DeserializeObject<TipoConsulta>(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el tipo de consulta especificada: " + ex.Message);
            }

            return tipo;
        }

        public static Cita ObtenerCita(int numero)
        {
            Cita cita = null;

            try
            {
                Socket<string> mensajeObtenerCita = new Socket<string>
                {
                    Metodo = "ObtenerCita",
                    Entidad = numero.ToString()
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensajeObtenerCita));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                cita = JsonConvert.DeserializeObject<Cita>(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener la cita especificada: " + ex.Message);
            }

            return cita;
        }

        public static List<TipoConsulta> ObtenerTiposConsultasActivas()
        {
            List<TipoConsulta> listaTipos = new List<TipoConsulta>();

            try
            {
                Socket<string> mensajeObtenerTiposConsultasActivas = new Socket<string>
                {
                    Metodo = "ObtenerTiposConsultasActivas"
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensajeObtenerTiposConsultasActivas));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                listaTipos = JsonConvert.DeserializeObject<List<TipoConsulta>>(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener los tipos de consultas activas registradas: " + ex.Message);
            }

            return listaTipos;
        }

        public static List<Doctor> ObtenerDoctoresActivos()
        {
            List<Doctor> listaDoctores = new List<Doctor>();

            try
            {
                Socket<string> mensajeObtenerDoctoresActivos = new Socket<string>
                {
                    Metodo = "ObtenerDoctoresActivos"
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensajeObtenerDoctoresActivos));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                listaDoctores = JsonConvert.DeserializeObject<List<Doctor>>(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener los doctores activos registrados: " + ex.Message);
            }

            return listaDoctores;
        }

        public static void AgregarCita(Cita cita)
        {
            try
            {
                Socket<Cita> mensajeAgregarCita = new Socket<Cita>
                {
                    Metodo = "AgregarCita",
                    Entidad = cita
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensajeAgregarCita));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                cita = JsonConvert.DeserializeObject<Cita>(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar la cita:" + ex.Message);
            }
        }

        public static List<Cita> ObtenerCitasCliente(int identificacion)
        {
            List<Cita> listaCitas = new List<Cita>();

            try
            {
                Socket<string> mensajeObtenerCitasCliente = new Socket<string>
                {
                    Metodo = "ObtenerCitasCliente",
                    Entidad = identificacion.ToString()
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(mensajeObtenerCitasCliente));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                listaCitas = JsonConvert.DeserializeObject<List<Cita>>(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener las citas del cliente: " + ex.Message);
            }

            return listaCitas;
        }
    }
}
