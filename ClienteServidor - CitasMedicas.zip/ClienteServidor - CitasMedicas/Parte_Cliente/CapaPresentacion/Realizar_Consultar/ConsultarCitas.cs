﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion.Realizar_Consultar
{
    public partial class ConsultarCitas : Form
    {
        Form1 form1;
        Cliente cliente;

        public ConsultarCitas(Form1 form1, Cliente cliente)
        {
            InitializeComponent();
            this.form1 = form1;
            this.cliente = cliente;
            label2.Text = "Cliente: " + cliente.Nombre + " " + cliente.Apellido1 + " " + cliente.Apellido2;
            mostrarCitas(cliente.Identificacion);
        }

        private void mostrarCitas(int identificacion)
        {
            List<Cita> ListaCitas = new List<Cita>();
            ListaCitas = ProtocoloTCP.ObtenerCitasCliente(identificacion);

            foreach (var cita in ListaCitas)
            {
                int rowIndex = dataGridView1.Rows.Add();
                dataGridView1.Rows[rowIndex].Cells[0].Value = cita.Numero;
                dataGridView1.Rows[rowIndex].Cells[1].Value = cita.FechaHora;
                dataGridView1.Rows[rowIndex].Cells[2].Value = cita.Tipo.Descripcion;
                dataGridView1.Rows[rowIndex].Cells[3].Value = cita.Doctor.Nombre;
                dataGridView1.Rows[rowIndex].Cells[4].Value = cita.Doctor.Apellido1;
                dataGridView1.Rows[rowIndex].Cells[5].Value = cita.Doctor.Apellido2;
            }
            label4.Text = "Citas asociadas: " + ListaCitas.Count;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            form1.Visible = true;
            this.Visible = false;
        }
    }
}
