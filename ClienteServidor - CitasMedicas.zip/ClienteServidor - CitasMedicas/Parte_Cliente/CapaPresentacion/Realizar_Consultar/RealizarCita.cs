﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaEntidades;

namespace CapaPresentacion.Realizar_Consultar
{
    public partial class RealizarCita : Form
    {
        Form1 form1;
        TipoConsulta tipo;
        Cliente cliente;
        Doctor doctor;

        public RealizarCita(Form1 form1, Cliente cliente)
        {
            InitializeComponent();
            this.form1 = form1;
            this.cliente = cliente;
            label2.Text = "Id: " + cliente.Identificacion + " Cliente: " + cliente.Nombre + " " + cliente.Apellido1 + " " + cliente.Apellido2;
            agregarTipos();
            agregarDoctores();
        }

        private void agregarTipos()
        {
            int i = 0;
            List<TipoConsulta> ListaTipos = new List<TipoConsulta>();
            ListaTipos = ProtocoloTCP.ObtenerTiposConsultasActivas();
            if (ListaTipos.Count != 0)
            {
                while (i != ListaTipos.Count)
                {
                    listBox1.Items.Add(ListaTipos.ElementAt(i).Numero);
                    i++;
                }
            }
            else
            {
                label1.Text = "No hay tipos de consultas activas registradas";
                dateTimePicker1.Enabled = false;
                dateTimePicker2.Enabled = false;
                textBox1.Enabled = false;
                button2.Enabled = false;
                listBox1.Enabled = false; listBox3.Enabled = false;
            }
        }

        private void agregarDoctores()
        {
            int i = 0;
            List<Doctor> ListaDoctores = new List<Doctor>();
            ListaDoctores = ProtocoloTCP.ObtenerDoctoresActivos();
            if (ListaDoctores.Count != 0)
            {
                while (i != ListaDoctores.Count)
                {
                    listBox3.Items.Add(ListaDoctores.ElementAt(i).Identificacion);
                    i++;
                }
            }
            else
            {
                label3.Text = "No hay doctores activos registrados";
                dateTimePicker1.Enabled = false;
                dateTimePicker2.Enabled = false;
                textBox1.Enabled = false;
                button2.Enabled = false;
                listBox1.Enabled = false; listBox3.Enabled = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int numero = int.Parse(textBox1.Text);
                DateTime fechayhora = new DateTime(dateTimePicker1.Value.Year, dateTimePicker1.Value.Month, dateTimePicker1.Value.Day, dateTimePicker2.Value.Hour, dateTimePicker2.Value.Minute, dateTimePicker2.Value.Second);

                if (tipo != null && cliente != null && doctor != null)
                {
                    if (ProtocoloTCP.ObtenerCita(numero) == null)
                    {
                        Cita cita = new Cita();
                        cita.Numero = numero;
                        cita.FechaHora = fechayhora;
                        cita.Tipo = tipo;
                        cita.Cliente = cliente;
                        cita.Doctor = doctor;
                        ProtocoloTCP.AgregarCita(cita);
                        MessageBox.Show("Cita registrada");
                    }
                    else
                    {
                        MessageBox.Show("El numero de la cita ya se encuentra registrado");
                    }
                }
                else
                {
                    MessageBox.Show("Debe seleccionar un registro de cada uno");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("El campo numero solo permite valores numericos");
            }
            textBox1.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            form1.Visible = true;
            this.Visible = false;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            tipo = ProtocoloTCP.ObtenerTipoConsulta(int.Parse(listBox1.SelectedItem.ToString()));
            label1.Text = "Tipo de Consulta: " + tipo.Descripcion;
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            doctor = ProtocoloTCP.ObtenerDoctor(int.Parse(listBox3.SelectedItem.ToString()));
            label3.Text = "Doctor: " + doctor.Nombre + " " + doctor.Apellido1 + " " + doctor.Apellido2;
        }
    }
}
