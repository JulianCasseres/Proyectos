﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion.TiposConsulta
{
    public partial class AdminTiposConsulta : Form
    {
        Form1 form1;

        public AdminTiposConsulta(Form1 form1)
        {
            InitializeComponent();
            this.form1 = form1;
            comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 1:
                    Registrar registra = new Registrar(this);
                    registra.Visible = true;
                    this.Visible = false;
                    comboBox1.SelectedIndex = 0;
                    break;

                case 2:
                    Consultar consulta = new Consultar(this);
                    consulta.Visible = true;
                    this.Visible = false;
                    comboBox1.SelectedIndex = 0;
                    break;

                case 3:
                    Modificar modifica = new Modificar(this);
                    modifica.Visible = true;
                    this.Visible = false;
                    comboBox1.SelectedIndex = 0;
                    break;

                case 4:
                    form1.Visible = true;
                    this.Visible = false;
                    break;

                default:
                    break;
            }
        }
    }
}
