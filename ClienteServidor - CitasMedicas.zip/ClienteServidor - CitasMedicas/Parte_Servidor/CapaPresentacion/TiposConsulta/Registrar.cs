﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaEntidades;
using CapaBiblioteca;

namespace CapaPresentacion.TiposConsulta
{
    public partial class Registrar : Form
    {
        AdminTiposConsulta control;
        DatosBiblioteca DatosServidor = new DatosBiblioteca();

        public Registrar(AdminTiposConsulta control)
        {
            InitializeComponent();
            this.control = control;
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int numero = int.Parse(textBox1.Text);
                string descripcion = textBox2.Text;
                char estado = comboBox1.SelectedItem.ToString()[0];

                if (!string.IsNullOrEmpty(descripcion))
                {
                    if (DatosServidor.ObtenerTipoConsulta(numero) == null)
                    {
                        if (estado.Equals('A') || estado.Equals('I'))
                        {
                            TipoConsulta tipo = new TipoConsulta();
                            tipo.Numero = numero;
                            tipo.Descripcion = descripcion;
                            tipo.Estado = estado;
                            DatosServidor.AgregarTipoConsulta(tipo);
                            MessageBox.Show("Tipo de consulta registrada");
                        }
                        else
                        {
                            MessageBox.Show("Seleccione un estado");
                        }
                    }
                    else
                    {
                        MessageBox.Show("El numero ya se encuentra registrado");
                    }
                }
                else
                {
                    MessageBox.Show("Revise que los campos no estén vacios");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("El campo id solo permite valores numericos");
            }
            textBox1.Text = ""; textBox2.Text = "";
            comboBox1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            control.Visible = true;
            this.Visible = false;
        }
    }
}
