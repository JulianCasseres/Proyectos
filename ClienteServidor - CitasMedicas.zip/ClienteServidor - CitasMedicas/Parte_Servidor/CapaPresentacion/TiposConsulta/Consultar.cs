﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaEntidades;
using CapaBiblioteca;

namespace CapaPresentacion.TiposConsulta
{
    public partial class Consultar : Form
    {
        AdminTiposConsulta control;
        DatosBiblioteca DatosServidor = new DatosBiblioteca();

        public Consultar(AdminTiposConsulta control)
        {
            InitializeComponent();
            this.control = control;
            mostrarConsultas();
        }

        void mostrarConsultas()
        {
            List<TipoConsulta> ListaTiposConsulta = new List<TipoConsulta>();
            ListaTiposConsulta = DatosServidor.ObtenerTiposConsultas();
            if (ListaTiposConsulta.Count != 0)
            {
                dataGridView1.DataSource = ListaTiposConsulta;
            }
            else
            {
                MessageBox.Show("No hay tipos de consultas registradas");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            control.Visible = true;
            this.Visible = false;
        }
    }
}
