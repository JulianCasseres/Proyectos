﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaBiblioteca;
using CapaEntidades;

namespace CapaPresentacion.TiposConsulta
{
    public partial class Modificar : Form
    {
        AdminTiposConsulta control;
        DatosBiblioteca DatosServidor = new DatosBiblioteca();
        TipoConsulta tipo = null;

        public Modificar(AdminTiposConsulta control)
        {
            InitializeComponent();
            this.control = control;
            button1.Enabled = false;
            button2.Enabled = false;
            comboBox1.SelectedIndex = 0;
            comboBox1.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString().Equals("Activo") || comboBox1.SelectedItem.ToString().Equals("Inactivo"))
            {
                tipo.Estado = comboBox1.SelectedItem.ToString()[0];
                DatosServidor.ModificarTipoConsulta(tipo);
                MessageBox.Show("Cambio realizado");
                button2_Click(sender, e);
            }
            else
            {
                MessageBox.Show("Seleccione un estado");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = true; textBox1.Text = "";
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = true;
            comboBox1.SelectedIndex = 0;
            comboBox1.Enabled = false;
            label3.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int numero = int.Parse(textBox1.Text);
                tipo = DatosServidor.ObtenerTipoConsulta(numero);
                if (tipo != null)
                {
                    label3.Text = "Descripcion: " + tipo.Descripcion;
                    textBox1.Enabled = false;
                    button1.Enabled = true;
                    button2.Enabled = true;
                    button3.Enabled = false;
                    comboBox1.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Tipo de Consulta NO encontrada");
                    textBox1.Text = "";
                }
            }
            catch(FormatException)
            {
                MessageBox.Show("Tipo de Consulta NO encontrada");
                textBox1.Text = "";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            control.Visible = true;
            this.Visible = false; 
        }
    }
}
