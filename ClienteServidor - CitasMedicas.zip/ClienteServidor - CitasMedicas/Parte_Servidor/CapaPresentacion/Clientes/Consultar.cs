﻿using CapaBiblioteca;
using CapaEntidades;
using CapaPresentacion.TiposConsulta;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion.Clientes
{
    public partial class Consultar : Form
    {
        AdminClientes control;
        DatosBiblioteca DatosServidor = new DatosBiblioteca();

        public Consultar(AdminClientes control)
        {
            InitializeComponent();
            this.control = control;
            mostrarClientes();
        }

        void mostrarClientes()
        {
            List<Cliente> ListaClientes = new List<Cliente>();
            ListaClientes = DatosServidor.ObtenerClientes();
            if (ListaClientes.Count != 0)
            {
                dataGridView1.DataSource = ListaClientes;
            }
            else
            {
                MessageBox.Show("No hay clientes registrados");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            control.Visible = true;
            this.Visible = false;
        }
    }
}
