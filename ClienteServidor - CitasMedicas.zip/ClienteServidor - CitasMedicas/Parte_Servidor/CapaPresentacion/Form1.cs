﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaPresentacion.TiposConsulta;
using CapaPresentacion.Clientes;
using CapaPresentacion.Doctores;
using CapaPresentacion.Citas;
using CapaPresentacion.Reportes;
using System.Net.Sockets;
using System.Net;
using System.Threading;
using CapaBiblioteca;
using CapaEntidades;
using System.IO;
using Newtonsoft.Json;

namespace CapaPresentacion
{
    public partial class Form1 : Form
    {
        TcpListener TCP;
        Thread EscucharClientes;
        DatosBiblioteca DatosServidor = new DatosBiblioteca();
        Bitacora bitacora;
        Conectados conectados;
        bool estado;

        public Form1()
        {
            InitializeComponent();
            bitacora = new Bitacora(MensajeBitacora);
            conectados = new Conectados(MensajeConectado);
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
            button2.Enabled = false;
            textBox1.ScrollBars = ScrollBars.Both;
        }

        private delegate void Bitacora(string texto);
        private delegate void Conectados(string texto, bool agregar);

        private void MensajeBitacora(string texto)
        {
            textBox1.AppendText(DateTime.Now.ToString() + " - " + texto);
            textBox1.AppendText(Environment.NewLine);
        }

        private void MensajeConectado(string texto, bool agregar)
        {
            if (agregar)
            {
                listBox1.Items.Add(texto);
            }
            else
            {
                listBox1.Items.Remove(texto);
            }

        }

        private void Escuchar()
        {
            TCP.Start();
            try
            {
                while (estado == true)
                {
                    TcpClient cliente = TCP.AcceptTcpClient();
                    Thread clienteThread = new Thread(new ParameterizedThreadStart(Comunicacion));
                    clienteThread.Start(cliente);
                }
            }
            catch (Exception)
            {
                return;
            }
        }

        private void Comunicacion(object cliente)
        {
            TcpClient tcCliente = (TcpClient)cliente;
            StreamReader reader = new StreamReader(tcCliente.GetStream());
            StreamWriter servidorStreamWriter = new StreamWriter(tcCliente.GetStream());

            while (estado)
            {
                try
                {
                    var mensaje = reader.ReadLine();
                    Socket<object> accion = JsonConvert.DeserializeObject<Socket<object>>(mensaje);
                    Accion(accion.Metodo, mensaje, ref servidorStreamWriter);
                }
                catch (Exception)
                {
                    break;
                }
            }
            tcCliente.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 1:
                    AdminTiposConsulta adminTc = new AdminTiposConsulta(this);
                    adminTc.Visible = true;
                    this.Visible = false;
                    break;

                case 2:
                    AdminClientes adminC = new AdminClientes(this);
                    adminC.Visible = true;
                    this.Visible = false;
                    break;

                case 3:
                    AdminDoctores adminD = new AdminDoctores(this);
                    adminD.Visible = true;
                    this.Visible = false;
                    break;

                case 4:
                    AdminCitas adminCt = new AdminCitas(this);
                    adminCt.Visible = true;
                    this.Visible = false;
                    break;

                default:
                    break;
            }
            comboBox1.SelectedIndex = 0;
        }

        public void Accion(string accion, string mensaje, ref StreamWriter servidorStreamWriter)
        {
            switch (accion)
            {
                case "ConectarCliente":
                    Socket<string> a = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    DatosServidor.ConectarCliente(int.Parse(a.Entidad));
                    textBox1.Invoke(bitacora, new object[] { a.Entidad + " se ha conectado" });
                    listBox1.Invoke(conectados, new object[] { a.Entidad, true });
                    break;

                case "DesconectarCliente":
                    Socket<string> b = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    DatosServidor.DesconectarCliente(int.Parse(b.Entidad));
                    textBox1.Invoke(bitacora, new object[] { b.Entidad + " se ha desconectado" });
                    listBox1.Invoke(conectados, new object[] { b.Entidad, false });
                    break;

                case "ObtenerCliente":
                    Socket<string> c = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    ObtenerCliente(int.Parse(c.Entidad), ref servidorStreamWriter);
                    break;

                case "ObtenerDoctor":
                    Socket<string> d = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    ObtenerDoctor(int.Parse(d.Entidad), ref servidorStreamWriter);
                    break;

                case "ObtenerTipoConsulta":
                    Socket<string> e = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    ObtenerTipoConsulta(int.Parse(e.Entidad), ref servidorStreamWriter);
                    break;

                case "ObtenerCita":
                    Socket<string> f = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    ObtenerCita(int.Parse(f.Entidad), ref servidorStreamWriter);
                    break;

                case "ObtenerTiposConsultasActivas":
                    ObtenerTiposConsultasActivas(ref servidorStreamWriter);
                    break;

                case "ObtenerDoctoresActivos":
                    ObtenerDoctoresActivos(ref servidorStreamWriter);
                    break;

                case "AgregarCita":
                    Socket<Cita> g = JsonConvert.DeserializeObject<Socket<Cita>>(mensaje);
                    AgregarCita(g.Entidad, ref servidorStreamWriter);
                    textBox1.Invoke(bitacora, new object[] { g.Entidad + " ha realizado una cita" });
                    break;

                case "ObtenerCitasCliente":
                    Socket<string> h = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    ObtenerCitasCliente(int.Parse(h.Entidad), ref servidorStreamWriter);
                    textBox1.Invoke(bitacora, new object[] { h.Entidad + " ha consultado sus citas" });
                    break;

                default:
                    break;
            }
        }

        public void ObtenerCliente(int identificacion, ref StreamWriter writer)
        {
            try
            {
                Cliente cliente = DatosServidor.ObtenerCliente(identificacion);
                var respuesta = JsonConvert.SerializeObject(cliente);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el cliente." + ex.Message);
            }
        }

        public void ObtenerDoctor(int identificacion, ref StreamWriter writer)
        {
            try
            {
                Doctor doctor = DatosServidor.ObtenerDoctor(identificacion);
                var respuesta = JsonConvert.SerializeObject(doctor);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el doctor." + ex.Message);
            }
        }

        public void ObtenerTipoConsulta(int numero, ref StreamWriter writer)
        {
            try
            {
                TipoConsulta tipo = DatosServidor.ObtenerTipoConsulta(numero);
                var respuesta = JsonConvert.SerializeObject(tipo);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el tipo de consulta." + ex.Message);
            }
        }

        public void ObtenerCita(int numero, ref StreamWriter writer)
        {
            try
            {
                Cita cita = DatosServidor.ObtenerCita(numero);
                var respuesta = JsonConvert.SerializeObject(cita);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener la cita." + ex.Message);
            }
        }

        public void ObtenerTiposConsultasActivas(ref StreamWriter writer)
        {
            try
            {
                List<TipoConsulta> listaTipos = DatosServidor.ObtenerTiposConsultasActivas();
                var respuesta = JsonConvert.SerializeObject(listaTipos);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener los tipos de consultas activas." + ex.Message);
            }
        }

        public void ObtenerDoctoresActivos(ref StreamWriter writer)
        {
            try
            {
                List<Doctor> listaDoctores = DatosServidor.ObtenerDoctoresActivos();
                var respuesta = JsonConvert.SerializeObject(listaDoctores);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener los doctores activos." + ex.Message);
            }
        }

        public void AgregarCita(Cita cita, ref StreamWriter writer)
        {
            try
            {
                DatosServidor.AgregarCita(cita);
                var respuesta = JsonConvert.SerializeObject(cita);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar la cita." + ex.Message);
            }
        }

        public void ObtenerCitasCliente(int identificacion, ref StreamWriter writer)
        {
            try
            {
                List<Cita> listaCitas = new List<Cita>();
                listaCitas = DatosServidor.ObtenerCitasCliente(identificacion);
                var respuesta = JsonConvert.SerializeObject(listaCitas);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener las citas del cliente." + ex.Message);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox2.SelectedIndex)
            {
                case 1:
                    PorFecha reportF = new PorFecha(this);
                    reportF.Visible = true;
                    this.Visible = false;
                    break;

                case 2:
                    PorCliente reportC = new PorCliente(this);
                    reportC.Visible = true;
                    this.Visible = false;
                    break;

                case 3:
                    PorDoctor reportD = new PorDoctor(this);
                    reportD.Visible = true;
                    this.Visible = false;
                    break;

                default:
                    break;
            }
            comboBox2.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                IPAddress local = IPAddress.Parse("127.0.0.1");
                TCP = new TcpListener(local, 14100);
                estado = true;

                EscucharClientes = new Thread(new ThreadStart(Escuchar));
                EscucharClientes.Start();
                EscucharClientes.IsBackground = true;
                button1.Enabled = false; button2.Enabled = true;
                textBox1.Text = "Servidor iniciado";
                textBox1.AppendText(Environment.NewLine);
            }
            catch (Exception)
            {
                MessageBox.Show("Error al iniciar el servidor");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(listBox1.Items.Count == 0)
            {
                estado = false;
                TCP.Stop();
                button1.Enabled = true; button2.Enabled = false;
                textBox1.Text = "Servidor apagado";
                textBox1.AppendText(Environment.NewLine);
            }
            else
            {
                MessageBox.Show("No puede apagar el servidor hasta que todos los usuarios se desconecten");
            }
        }
    }
}
