﻿using CapaBiblioteca;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion.Doctores
{
    public partial class Registrar : Form
    {
        AdminDoctores control;
        DatosBiblioteca DatosServidor = new DatosBiblioteca();

        public Registrar(AdminDoctores control)
        {
            InitializeComponent();
            this.control = control;
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(textBox1.Text);
                string nombre = textBox2.Text;
                string apellido1 = textBox3.Text;
                string apellido2 = textBox4.Text;
                char estado = comboBox1.SelectedItem.ToString()[0];

                if (!string.IsNullOrEmpty(nombre) && !string.IsNullOrEmpty(apellido1) && !string.IsNullOrEmpty(apellido2))
                {
                    if (DatosServidor.ObtenerDoctor(id) == null)
                    {
                        if (estado.Equals('A') || estado.Equals('I'))
                        {
                            Doctor doctor = new Doctor();
                            doctor.Identificacion = id;
                            doctor.Nombre = nombre;
                            doctor.Apellido1 = apellido1;
                            doctor.Apellido2 = apellido2;
                            doctor.Estado = estado;
                            DatosServidor.AgregarDoctor(doctor);
                            MessageBox.Show("Doctor registrado");
                        }
                        else
                        {
                            MessageBox.Show("Seleccione un estado");
                        }
                    }
                    else
                    {
                        MessageBox.Show("El id ya se encuentra registrado");
                    }
                }
                else
                {
                    MessageBox.Show("Revise que los campos no estén vacios");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("El campo id solo permite valores numericos");
            }
            textBox1.Text = ""; textBox2.Text = "";
            textBox3.Text = ""; textBox4.Text = "";
            comboBox1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            control.Visible = true;
            this.Visible = false;
        }
    }
}
