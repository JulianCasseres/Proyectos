﻿using CapaBiblioteca;
using CapaEntidades;
using CapaPresentacion.Clientes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion.Doctores
{
    public partial class Modificar : Form
    {
        AdminDoctores control;
        DatosBiblioteca DatosServidor = new DatosBiblioteca();
        Doctor doctor = null;

        public Modificar(AdminDoctores control)
        {
            InitializeComponent();
            this.control = control;
            button1.Enabled = false;
            button2.Enabled = false;
            comboBox1.SelectedIndex = 0;
            comboBox1.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString().Equals("Activo") || comboBox1.SelectedItem.ToString().Equals("Inactivo"))
            {
                doctor.Estado = comboBox1.SelectedItem.ToString()[0];
                DatosServidor.ModificarDoctor(doctor);
                MessageBox.Show("Cambio realizado");
                button2_Click(sender, e);
            }
            else
            {
                MessageBox.Show("Seleccione un genero y verifique que la fecha sea correcta");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = true; textBox1.Text = "";
            label3.Text = "";
            button1.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = true;
            comboBox1.SelectedIndex = 0;
            comboBox1.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int identificacion = int.Parse(textBox1.Text);
                doctor = DatosServidor.ObtenerDoctor(identificacion);
                if (doctor != null)
                {
                    label3.Text = "Nombre: " + doctor.Nombre + " " + doctor.Apellido1 + " " + doctor.Apellido2;
                    textBox1.Enabled = false;
                    button1.Enabled = true;
                    button2.Enabled = true;
                    button3.Enabled = false;
                    comboBox1.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Doctor NO encontrado");
                    textBox1.Text = "";
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Doctor NO encontrado");
                textBox1.Text = "";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            control.Visible = true;
            this.Visible = false;
        }
    }
}
