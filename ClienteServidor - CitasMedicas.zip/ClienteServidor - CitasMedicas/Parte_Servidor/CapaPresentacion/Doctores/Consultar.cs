﻿using CapaBiblioteca;
using CapaEntidades;
using CapaPresentacion.Clientes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion.Doctores
{
    public partial class Consultar : Form
    {
        AdminDoctores control;
        DatosBiblioteca DatosServidor = new DatosBiblioteca();

        public Consultar(AdminDoctores control)
        {
            InitializeComponent();
            this.control = control;
            mostrarDoctores();
        }

        void mostrarDoctores()
        {
            List<Doctor> ListaDoctores = new List<Doctor>();
            ListaDoctores = DatosServidor.ObtenerDoctores();
            if (ListaDoctores.Count != 0)
            {
                dataGridView1.DataSource = ListaDoctores;
            }
            else
            {
                MessageBox.Show("No hay doctoress registrados");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            control.Visible = true;
            this.Visible = false;
        }
    }
}
