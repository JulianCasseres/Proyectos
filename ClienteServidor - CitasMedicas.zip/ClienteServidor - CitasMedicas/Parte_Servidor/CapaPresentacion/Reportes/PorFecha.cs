﻿using CapaBiblioteca;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion.Reportes
{
    public partial class PorFecha : Form
    {
        Form1 form1;
        DatosBiblioteca DatosServidor = new DatosBiblioteca();

        public PorFecha(Form1 form1)
        {
            InitializeComponent();
            this.form1 = form1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            form1.Visible = true;
            this.Visible = false;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            List<Cita> ListaCitas = new List<Cita>();
            string fecha = "";
            fecha += dateTimePicker1.Value.Year + "-" + dateTimePicker1.Value.Month + "-" + dateTimePicker1.Value.Day;
            ListaCitas = DatosServidor.ObtenerCitasFecha(fecha);

            foreach (var cita in ListaCitas)
            {
                int rowIndex = dataGridView1.Rows.Add();
                dataGridView1.Rows[rowIndex].Cells[0].Value = cita.Numero;
                dataGridView1.Rows[rowIndex].Cells[1].Value = cita.FechaHora;
                dataGridView1.Rows[rowIndex].Cells[2].Value = cita.Tipo.Descripcion;
                dataGridView1.Rows[rowIndex].Cells[3].Value = cita.Cliente.Nombre;
                dataGridView1.Rows[rowIndex].Cells[4].Value = cita.Cliente.Apellido1;
                dataGridView1.Rows[rowIndex].Cells[5].Value = cita.Cliente.Apellido2;
                dataGridView1.Rows[rowIndex].Cells[6].Value = cita.Doctor.Nombre;
                dataGridView1.Rows[rowIndex].Cells[7].Value = cita.Doctor.Apellido1;
                dataGridView1.Rows[rowIndex].Cells[8].Value = cita.Doctor.Apellido2;
            }
            label4.Text = "Citas asociadas: " + ListaCitas.Count;
        }
    }
}
