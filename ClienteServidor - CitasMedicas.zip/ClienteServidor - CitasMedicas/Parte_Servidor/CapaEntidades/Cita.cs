﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    [Serializable]
    public class Cita
    {
        public int Numero { get; set; }
        public DateTime FechaHora { get; set; }
        public TipoConsulta Tipo { get; set; }
        public Cliente Cliente { get; set; }
        public Doctor Doctor { get; set; }
    }
}
