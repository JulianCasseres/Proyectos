﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    [Serializable]
    public class Socket<T>
    {
        public string Metodo { get; set; }
        public T Entidad { get; set; }

        public Socket(){}

        public Socket(string metodo, T entidad)
        {
            Metodo = metodo;
            Entidad = entidad;
        }
    }
}
