﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using CapaEntidades;
using System.Configuration;
using System.Windows.Forms;

namespace CapaBiblioteca
{
    public class DatosBiblioteca
    {
        private string cadenaConexion;
        static List<int> Conectados = new List<int>();
        static SemaphoreSlim semaforoAccesoBaseDatos = new SemaphoreSlim(1);

        public DatosBiblioteca()
        {
            cadenaConexion = ConfigurationManager.ConnectionStrings["conexionDENTUNED"].ConnectionString;
        }

        public void ConectarCliente(int identificacion)
        {
            Conectados.Add(identificacion);
        }

        public void DesconectarCliente(int identificacion)
        {
            Conectados.Remove(identificacion);
        }

        public List<TipoConsulta> ObtenerTiposConsultas()
        {
            List<TipoConsulta> listaTipos = new List<TipoConsulta>();
            string sentencia = "SELECT * FROM Tipo_Consulta";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.CommandType = CommandType.Text;
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    TipoConsulta tipo = new TipoConsulta();
                                    tipo.Numero = Convert.ToInt32(reader.GetDecimal(0));
                                    tipo.Descripcion = reader.GetString(1);
                                    tipo.Estado = Convert.ToChar(reader.GetString(2));
                                    listaTipos.Add(tipo);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener los tipos de consulta registradas: {ex.Message}");
            }

            return listaTipos;
        }

        public TipoConsulta ObtenerTipoConsulta(int numero)
        {
            TipoConsulta tipo = new TipoConsulta();
            string sentencia = "SELECT numero, descripcion, estado FROM Tipo_Consulta WHERE numero = @numero";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.CommandType = CommandType.Text;
                        comando.Parameters.AddWithValue("@numero", numero);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    tipo.Numero = Convert.ToInt32(reader.GetDecimal(0));
                                    tipo.Descripcion = reader.GetString(1);
                                    tipo.Estado = Convert.ToChar(reader.GetString(2));
                                }
                            }
                            else
                            {
                                tipo = null;
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener el tipo de consulta especificada: {ex.Message}");
            }

            return tipo;
        }

        public void AgregarTipoConsulta(TipoConsulta tipo)
        {
            string sentencia = "INSERT INTO Tipo_Consulta (numero, descripcion, estado) VALUES (@numero, @descripcion, @estado)";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand())
                    {
                        comando.CommandType = CommandType.Text;
                        comando.CommandText = sentencia;
                        comando.Connection = conexion;
                        comando.Parameters.AddWithValue("@numero", tipo.Numero);
                        comando.Parameters.AddWithValue("@descripcion", tipo.Descripcion);
                        comando.Parameters.AddWithValue("@estado", tipo.Estado);

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al agregar el tipo de consulta: {ex.Message}");
            }
        }

        public void ModificarTipoConsulta(TipoConsulta tipo)
        {
            string sentencia = "UPDATE Tipo_Consulta SET numero = @nuevoNumero, descripcion = @nuevaDescripcion, estado = @nuevoEstado WHERE numero = @numero";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand())
                    {
                        comando.CommandType = CommandType.Text;
                        comando.CommandText = sentencia;
                        comando.Connection = conexion;

                        comando.Parameters.AddWithValue("@nuevoNumero", tipo.Numero);
                        comando.Parameters.AddWithValue("@nuevaDescripcion", tipo.Descripcion);
                        comando.Parameters.AddWithValue("@nuevoEstado", tipo.Estado);
                        comando.Parameters.AddWithValue("@numero", tipo.Numero);

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al modificar el tipo de consulta: {ex.Message}");
            }
        }

        public List<Cliente> ObtenerClientes()
        {
            List<Cliente> listaClientes = new List<Cliente>();
            string sentencia = "SELECT * FROM Cliente";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Cliente cliente = new Cliente();
                                    cliente.Identificacion = Convert.ToInt32(reader.GetDecimal(0));
                                    cliente.Nombre = reader.GetString(1);
                                    cliente.Apellido1 = reader.GetString(2);
                                    cliente.Apellido2 = reader.GetString(3);
                                    cliente.FechaNacimiento = reader.GetDateTime(4);
                                    cliente.Genero = Convert.ToChar(reader.GetString(5));
                                    listaClientes.Add(cliente);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener los clientes registrados: {ex.Message}");
            }

            return listaClientes;
        }

        public Cliente ObtenerCliente(int identificacion)
        {
            Cliente cliente = new Cliente();
            string sentencia = "SELECT identificacion, nombre, apellido1, apellido2, fec_nacimiento, genero FROM Cliente WHERE identificacion = @identificacion";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.CommandType = CommandType.Text;
                        comando.Parameters.AddWithValue("@identificacion", identificacion);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    cliente.Identificacion = Convert.ToInt32(reader.GetDecimal(0));
                                    cliente.Nombre = reader.GetString(1);
                                    cliente.Apellido1 = reader.GetString(2);
                                    cliente.Apellido2 = reader.GetString(3);
                                    cliente.FechaNacimiento = reader.GetDateTime(4);
                                    cliente.Genero = Convert.ToChar(reader.GetString(5));
                                }
                            }
                            else
                            {
                                cliente = null;
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener el cliente especificado: {ex.Message}");
            }

            return cliente;
        }

        public void AgregarCliente(Cliente cliente)
        {
            string sentencia = "INSERT INTO Cliente (identificacion, nombre, apellido1, apellido2, fec_nacimiento, genero) VALUES (@identificacion, @nombre, @apellido1, @apellido2, @fec_nacimiento, @genero)";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@identificacion", cliente.Identificacion);
                        comando.Parameters.AddWithValue("@nombre", cliente.Nombre);
                        comando.Parameters.AddWithValue("@apellido1", cliente.Apellido1);
                        comando.Parameters.AddWithValue("@apellido2", cliente.Apellido2);
                        comando.Parameters.AddWithValue("@fec_nacimiento", cliente.FechaNacimiento);
                        comando.Parameters.AddWithValue("@genero", cliente.Genero);

                        comando.CommandType = CommandType.Text;
                        comando.Connection = conexion;

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al agregar el cliente: {ex.Message}");
            }
        }

        public void ModificarCliente(Cliente cliente)
        {
            string sentencia = "UPDATE Cliente SET identificacion = @identificacion, nombre = @nombre, apellido1 = @apellido1, apellido2 = @apellido2, genero = @genero, fec_nacimiento = @fec_nacimiento WHERE identificacion = @identificacion";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@identificacion", cliente.Identificacion);
                        comando.Parameters.AddWithValue("@nombre", cliente.Nombre);
                        comando.Parameters.AddWithValue("@apellido1", cliente.Apellido1);
                        comando.Parameters.AddWithValue("@apellido2", cliente.Apellido2);
                        comando.Parameters.AddWithValue("@genero", cliente.Genero);
                        comando.Parameters.AddWithValue("@fec_nacimiento", cliente.FechaNacimiento);

                        comando.CommandType = CommandType.Text;
                        comando.Connection = conexion;

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al modificar el cliente: {ex.Message}");
            }
        }

        public List<Doctor> ObtenerDoctores()
        {
            List<Doctor> listaDoctores = new List<Doctor>();
            string sentencia = "SELECT * FROM Doctor";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Doctor doctor = new Doctor();
                                    doctor.Identificacion = Convert.ToInt32(reader.GetDecimal(0));
                                    doctor.Nombre = reader.GetString(1);
                                    doctor.Apellido1 = reader.GetString(2);
                                    doctor.Apellido2 = reader.GetString(3);
                                    doctor.Estado = Convert.ToChar(reader.GetString(4));
                                    listaDoctores.Add(doctor);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener los doctores registrados: {ex.Message}");
            }

            return listaDoctores;
        }

        public Doctor ObtenerDoctor(int identificacion)
        {
            Doctor doctor = new Doctor();
            string sentencia = "SELECT identificacion, nombre, apellido1, apellido2, estado FROM Doctor WHERE identificacion = @identificacion";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.CommandType = CommandType.Text;
                        comando.Parameters.AddWithValue("@identificacion", identificacion);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    doctor.Identificacion = Convert.ToInt32(reader.GetDecimal(0));
                                    doctor.Nombre = reader.GetString(1);
                                    doctor.Apellido1 = reader.GetString(2);
                                    doctor.Apellido2 = reader.GetString(3);
                                    doctor.Estado = Convert.ToChar(reader.GetString(4));
                                }
                            }
                            else
                            {
                                doctor = null;
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener el doctor especificado: {ex.Message}");
            }

            return doctor;
        }

        public void AgregarDoctor(Doctor doctor)
        {
            string sentencia = "INSERT INTO Doctor (identificacion, nombre, apellido1, apellido2, estado) VALUES (@identificacion, @nombre, @apellido1, @apellido2, @estado)";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@identificacion", doctor.Identificacion);
                        comando.Parameters.AddWithValue("@nombre", doctor.Nombre);
                        comando.Parameters.AddWithValue("@apellido1", doctor.Apellido1);
                        comando.Parameters.AddWithValue("@apellido2", doctor.Apellido2);
                        comando.Parameters.AddWithValue("@estado", doctor.Estado);

                        comando.CommandType = CommandType.Text;
                        comando.Connection = conexion;

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al agregar el doctor: {ex.Message}");
            }
        }

        public void ModificarDoctor(Doctor doctor)
        {
            string sentencia = "UPDATE Doctor SET nombre = @nombre, apellido1 = @apellido1, apellido2 = @apellido2, estado = @estado WHERE identificacion = @identificacion";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@nombre", doctor.Nombre);
                        comando.Parameters.AddWithValue("@apellido1", doctor.Apellido1);
                        comando.Parameters.AddWithValue("@apellido2", doctor.Apellido2);
                        comando.Parameters.AddWithValue("@estado", doctor.Estado);
                        comando.Parameters.AddWithValue("@identificacion", doctor.Identificacion);

                        comando.CommandType = CommandType.Text;
                        comando.Connection = conexion;

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al modificar el doctor: {ex.Message}");
            }
        }

        public Cita ObtenerCita(int numero)
        {
            Cita cita = new Cita();
            string sentencia = "SELECT numero, fec_hor_cita, cod_tip_consulta, id_cliente, id_doctor FROM Cita WHERE numero = @numero";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.CommandType = CommandType.Text;
                        comando.Parameters.AddWithValue("@numero", numero);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    cita.Numero = Convert.ToInt32(reader.GetDecimal(0));
                                    cita.FechaHora = reader.GetDateTime(1);
                                }
                            }
                            else
                            {
                                cita = null;
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener la cita especificada: {ex.Message}");
            }

            return cita;
        }

        public void AgregarCita(Cita cita)
        {
            string sentencia = "INSERT INTO Cita (numero, fec_hor_cita, cod_tip_consulta, id_cliente, id_doctor) VALUES (@numero, @fec_hor_cita, @cod_tip_consulta, @id_cliente, @id_doctor)";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@numero", cita.Numero);
                        comando.Parameters.AddWithValue("@fec_hor_cita", cita.FechaHora);
                        comando.Parameters.AddWithValue("@cod_tip_consulta", cita.Tipo.Numero);
                        comando.Parameters.AddWithValue("@id_cliente", cita.Cliente.Identificacion);
                        comando.Parameters.AddWithValue("@id_doctor", cita.Doctor.Identificacion);

                        comando.CommandType = CommandType.Text;
                        comando.Connection = conexion;

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al agregar la cita: {ex.Message}");
            }
        }

        public List<TipoConsulta> ObtenerTiposConsultasActivas()
        {
            List<TipoConsulta> listaTipos = new List<TipoConsulta>();
            string sentencia = "SELECT numero, descripcion, estado FROM Tipo_Consulta WHERE estado = @estado";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@estado", "A");
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    TipoConsulta tipo = new TipoConsulta();
                                    tipo.Numero = Convert.ToInt32(reader.GetDecimal(0));
                                    tipo.Estado = Convert.ToChar(reader.GetString(2));
                                    listaTipos.Add(tipo);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener los tipos de consulta activas: {ex.Message}");
            }

            return listaTipos;
        }

        public List<Doctor> ObtenerDoctoresActivos()
        {
            List<Doctor> listaDoctores = new List<Doctor>();
            string sentencia = "SELECT identificacion, nombre, apellido1, apellido2, estado FROM Doctor WHERE estado = @estado";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@estado", "A");
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Doctor doctor = new Doctor();
                                    doctor.Identificacion = Convert.ToInt32(reader.GetDecimal(0));
                                    doctor.Estado = Convert.ToChar(reader.GetString(4));
                                    listaDoctores.Add(doctor);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener los doctores activos: {ex.Message}");
            }

            return listaDoctores;
        }

        public List<Cita> ObtenerCitasFecha(string fecha)
        {
            List<Cita> listaCitas = new List<Cita>();
            string sentencia = "SELECT cita.numero, cita.fec_hor_cita, tipo.descripcion, cliente.nombre, cliente.apellido1, cliente.apellido2, doctor.nombre, doctor.apellido1, doctor.apellido2 FROM Cita cita " +
                                "INNER JOIN Tipo_Consulta tipo ON cita.cod_tip_consulta = tipo.numero " +
                                "INNER JOIN Doctor doctor ON cita.id_doctor = doctor.identificacion " +
                                "INNER JOIN Cliente cliente ON cita.id_cliente = cliente.identificacion " +
                                "WHERE CAST(cita.fec_hor_cita AS DATE) = @fecha";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@fecha", DateTime.Parse(fecha));
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Cita cita = new Cita
                                    {
                                        Numero = Convert.ToInt32(reader.GetDecimal(0)),
                                        FechaHora = reader.GetDateTime(1),
                                        Tipo = new TipoConsulta { Descripcion = reader.GetString(2) },
                                        Cliente = new Cliente { Nombre = reader.GetString(3), Apellido1 = reader.GetString(4), Apellido2 = reader.GetString(5) },
                                        Doctor = new Doctor { Nombre = reader.GetString(6), Apellido1 = reader.GetString(7), Apellido2 = reader.GetString(8) }
                                    };
                                    listaCitas.Add(cita);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener las citas por fecha: {ex.Message}");
            }

            return listaCitas;
        }

        public List<Cita> ObtenerCitasCliente(int identificacion)
        {
            List<Cita> listaCitas = new List<Cita>();
            string sentencia = "SELECT cita.numero, cita.fec_hor_cita, tipo.descripcion, doctor.nombre, doctor.apellido1, doctor.apellido2 FROM Cita cita " +
                                "INNER JOIN Doctor doctor ON cita.id_doctor = doctor.identificacion " +
                                "INNER JOIN Tipo_Consulta tipo ON cita.cod_tip_consulta = tipo.numero " +
                                "WHERE cita.id_cliente = @identificacion";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@identificacion", identificacion);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Cita cita = new Cita
                                    {
                                        Numero = Convert.ToInt32(reader.GetDecimal(0)),
                                        FechaHora = reader.GetDateTime(1),
                                        Tipo = new TipoConsulta { Descripcion = reader.GetString(2) },
                                        Doctor = new Doctor { Nombre = reader.GetString(3), Apellido1 = reader.GetString(4), Apellido2 = reader.GetString(5) }
                                    };
                                    listaCitas.Add(cita);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener las citas por cliente: {ex.Message}");
            }

            return listaCitas;
        }

        public List<Cita> ObtenerCitasDoctor(int identificacion)
        {
            List<Cita> listaCitas = new List<Cita>();
            string sentencia = "SELECT cita.numero, cita.fec_hor_cita, tipo.descripcion, cliente.nombre, cliente.apellido1, cliente.apellido2 FROM Cita cita " +
                                "INNER JOIN Cliente cliente ON cita.id_cliente = cliente.identificacion " +
                                "INNER JOIN Tipo_Consulta tipo ON cita.cod_tip_consulta = tipo.numero " +
                                "WHERE cita.id_doctor = @identificacion";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@identificacion", identificacion);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Cita cita = new Cita
                                    {
                                        Numero = Convert.ToInt32(reader.GetDecimal(0)),
                                        FechaHora = reader.GetDateTime(1),
                                        Tipo = new TipoConsulta { Descripcion = reader.GetString(2) },
                                        Cliente = new Cliente { Nombre = reader.GetString(3), Apellido1 = reader.GetString(4), Apellido2 = reader.GetString(5) }
                                    };
                                    listaCitas.Add(cita);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener las citas por doctor: {ex.Message}");
            }

            return listaCitas;
        }
    }
}
