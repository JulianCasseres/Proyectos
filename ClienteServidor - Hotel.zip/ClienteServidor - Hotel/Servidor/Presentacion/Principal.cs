﻿using Entidades;
using Newtonsoft.Json;
using SentenciasSQL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace Presentacion
{
    public partial class Principal : Form
    {
        TcpListener TCP;
        Thread EscucharClientes;
        Sentencias sentencias = new Sentencias();
        Bitacora bitacora;
        Conectados conectados;
        public bool estado = false;

        public Principal()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
            bitacora = new Bitacora(MensajeBitacora);
            conectados = new Conectados(MensajeConectado);
            comboBox1.SelectedIndex = 0;
            button2.Enabled = false;
        }

        private delegate void Bitacora(string texto);
        private delegate void Conectados(string texto, bool agregar);

        private void MensajeBitacora(string texto)
        {
            textBox1.AppendText(DateTime.Now.ToString() + " - " + texto);
            textBox1.AppendText(Environment.NewLine);
        }

        private void MensajeConectado(string texto, bool agregar)
        {
            if (agregar)
            {
                listBox1.Items.Add(texto);
            }
            else
            {
                listBox1.Items.Remove(texto);
            }

        }

        private void Escuchar()
        {
            try
            {
                TCP.Start();
                while (estado)
                {
                    TcpClient cliente = TCP.AcceptTcpClient();
                    Thread clienteThread = new Thread(new ParameterizedThreadStart(Comunicacion));
                    clienteThread.Start(cliente);
                }
            }
            catch (SocketException ex)
            {
                if (ex.SocketErrorCode != SocketError.Interrupted)
                {
                    MessageBox.Show("Error de socket al escuchar clientes: " + ex.Message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al escuchar clientes: " + ex.Message);
            }
        }

        private void Comunicacion(object cliente)
        {
            TcpClient tcCliente = (TcpClient)cliente;
            StreamReader reader = new StreamReader(tcCliente.GetStream());
            StreamWriter servidorStreamWriter = new StreamWriter(tcCliente.GetStream());

            while (estado)
            {
                try
                {
                    var mensaje = reader.ReadLine();
                    Socket<object> accion = JsonConvert.DeserializeObject<Socket<object>>(mensaje);
                    Metodos(accion.Metodo, mensaje, ref servidorStreamWriter);
                }
                catch (Exception)
                {
                    break;
                }
            }
            tcCliente.Close();
        }

        public void Metodos(string metodo, string mensaje, ref StreamWriter servidorStreamWriter)
        {
            switch (metodo)
            {
                case "ConectarCliente":
                    Socket<string> solicitudConectar = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    sentencias.Conectar(solicitudConectar.Entidad);
                    if (sentencias.ObtenerCliente(solicitudConectar.Entidad) != null)
                    {
                        textBox1.Invoke(bitacora, new object[] { solicitudConectar.Entidad + " se ha conectado" });
                        listBox1.Invoke(conectados, new object[] { solicitudConectar.Entidad, true });
                    }
                    break;

                case "DesconectarCliente":
                    Socket<string> solicitudDesconectar = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    if (sentencias.ObtenerCliente(solicitudDesconectar.Entidad) != null)
                    {
                        textBox1.Invoke(bitacora, new object[] { solicitudDesconectar.Entidad + " se ha desconectado" });
                        listBox1.Invoke(conectados, new object[] { solicitudDesconectar.Entidad, false });
                    }
                    sentencias.Desconectar(solicitudDesconectar.Entidad);
                    break;

                case "EstadoConexion":
                    Socket<string> solicitudConexion = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    EstadoConexion(solicitudConexion.Entidad, ref servidorStreamWriter);
                    break;

                case "ObtenerCliente":
                    Socket<string> solicitudCliente = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    ObtenerCliente(solicitudCliente.Entidad, ref servidorStreamWriter);
                    break;

                case "HotelesDisponibles":
                    HotelesDisponibles(ref servidorStreamWriter);
                    break;

                case "ArticulosAsignados":
                    Socket<string> solicitudAsignados = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    ArticulosAsignados(int.Parse(solicitudAsignados.Entidad), ref servidorStreamWriter);
                    break;

                case "AgregarPedido":
                    Socket<Pedido> solicitudPedido = JsonConvert.DeserializeObject<Socket<Pedido>>(mensaje);
                    AgregarPedido(solicitudPedido.Entidad, ref servidorStreamWriter);
                    break;

                case "ConsultarPedidos":
                    Socket<string> solicitudPedidos = JsonConvert.DeserializeObject<Socket<string>>(mensaje);
                    ConsultarPedidos(solicitudPedidos.Entidad, ref servidorStreamWriter);
                    textBox1.Invoke(bitacora, new object[] { solicitudPedidos.Entidad + " ha consultado sus pedidos" });
                    break;

                default:
                    break;
            }
        }

        public void ObtenerCliente(string identificacion, ref StreamWriter writer)
        {
            Cliente cliente = sentencias.ObtenerCliente(identificacion);
            var respuesta = JsonConvert.SerializeObject(cliente);
            writer.WriteLine(respuesta);
            writer.Flush();
        }

        public void HotelesDisponibles(ref StreamWriter writer)
        {
            try
            {
                List<Hotel> listaHoteles = sentencias.HotelesDisponibles();
                var respuesta = JsonConvert.SerializeObject(listaHoteles);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception){}
        }

        public void ArticulosAsignados(int IdHotel, ref StreamWriter writer)
        {
            try
            {
                List<ArticuloHotel> listaDoctores = sentencias.ArticulosAsignadosHotel(IdHotel);
                var respuesta = JsonConvert.SerializeObject(listaDoctores);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception)
            {
                MessageBox.Show("Se ha producido un error al procesar la solicitud");
            }
        }

        public void AgregarPedido(Pedido pedido, ref StreamWriter writer)
        {
            try
            {
                bool verificar = sentencias.AgregarPedido(pedido);
                if (verificar)
                {
                    textBox1.Invoke(bitacora, new object[] { pedido.IdCliente + " ha realizado un pedido" });
                }
                pedido = new Pedido();
                var respuesta = JsonConvert.SerializeObject(pedido);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception)
            {
                MessageBox.Show("Se ha producido un error al procesar la solicitud");
            }
        }

        public void ConsultarPedidos(string identificacion, ref StreamWriter writer)
        {
            try
            {
                List<Pedido> listaPedidos = new List<Pedido>();
                listaPedidos = sentencias.ConsultarPedidos(identificacion);
                var respuesta = JsonConvert.SerializeObject(listaPedidos);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception)
            {
                MessageBox.Show("Se ha producido un error al procesar la solicitud");
            }
        }

        public void EstadoConexion(string identificacion, ref StreamWriter writer)
        {
            try
            {
                bool estado = false;
                int contador = 0;
                for(int i = 0; i < listBox1.Items.Count; i++)
                {
                    if (listBox1.Items[i].ToString() == identificacion)
                    {
                        contador++;
                    }
                }

                if (contador != 1)
                {
                    estado = true;
                }

                var respuesta = JsonConvert.SerializeObject(estado);
                writer.WriteLine(respuesta);
                writer.Flush();
            }
            catch (Exception)
            {
                MessageBox.Show("Se ha producido un error al procesar la solicitud");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int opcion = comboBox1.SelectedIndex;
            switch (opcion)
            {
                case 1:
                    RegistrarHotel RH = new RegistrarHotel(this);
                    RH.Visible = true;
                    this.Visible = false;
                    break;

                case 2:
                    RegistrarCategoria RCa = new RegistrarCategoria(this);
                    RCa.Visible = true;
                    this.Visible = false;
                    break;

                case 3:
                    RegistrarArticulo RA = new RegistrarArticulo(this);
                    RA.Visible = true;
                    this.Visible = false;
                    break;

                case 4:
                    RegistrarCliente RCl = new RegistrarCliente(this);
                    RCl.Visible = true;
                    this.Visible = false;
                    break;

                case 5:
                    RegistrarArticuloHotel RAH = new RegistrarArticuloHotel(this);
                    RAH.Visible = true;
                    this.Visible = false;
                    break;

                case 6:
                    ConsultarHoteles CH = new ConsultarHoteles(this);
                    CH.Visible = true;
                    this.Visible = false;
                    break;

                case 7:
                    ConsultarCategorias CCa = new ConsultarCategorias(this);
                    CCa.Visible = true;
                    this.Visible = false;
                    break;

                case 8:
                    ConsultarArticulos CA = new ConsultarArticulos(this);
                    CA.Visible = true;
                    this.Visible = false;
                    break;

                case 9:
                    ConsultarClientes CCl = new ConsultarClientes(this);
                    CCl.Visible = true;
                    this.Visible = false;
                    break;

                case 10:
                    ConsultarArticulosHotel CAH = new ConsultarArticulosHotel(this);
                    CAH.Visible = true;
                    this.Visible = false;
                    break;

                default:
                    break;
            }
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                IPAddress local = IPAddress.Parse("127.0.0.1");
                TCP = new TcpListener(local, 13200);
                estado = true;

                EscucharClientes = new Thread(new ThreadStart(Escuchar));
                EscucharClientes.Start();
                EscucharClientes.IsBackground = true;
                button1.Enabled = false;
                button2.Enabled = true;
                textBox1.Text = "Servidor iniciado";
                textBox1.AppendText(Environment.NewLine);
            }
            catch (SocketException ex)
            {
                MessageBox.Show("Error de socket al iniciar el servidor: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al iniciar el servidor: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (listBox1.Items.Count == 0)
                {
                    estado = false;
                    TCP.Stop();
                    button1.Enabled = true;
                    button2.Enabled = false;
                    textBox1.Text = "Servidor apagado";
                    textBox1.AppendText(Environment.NewLine);
                }
                else
                {
                    MessageBox.Show("No puede apagar el servidor hasta que todos los clientes se desconecten");
                }
            }
            catch (SocketException ex)
            {
                MessageBox.Show("Error al detener el servidor: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error general al detener el servidor: " + ex.Message);
            }
        }

        private void Principal_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if(estado)
                {
                    e.Cancel = true;
                    button2_Click(sender, e);
                }
            }
        }
    }
}
