﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using SentenciasSQL;

namespace Presentacion
{
    public partial class RegistrarArticuloHotel : Form
    {
        Principal principal;
        Sentencias sentencias = new Sentencias();

        public RegistrarArticuloHotel(Principal principal)
        {
            InitializeComponent();
            this.principal = principal;
            agregarHoteles();
            mostrarArticulos();
            comboBox1.SelectedIndex = 0;
            dataGridView2.Enabled = false;
        }

        private void agregarHoteles()
        {
            List<Hotel> listaHoteles = sentencias.HotelesDisponibles();
            if (listaHoteles.Count != 0)
            {
                label2.Text = "Hoteles Disponibles";
                for (int i = 0; i < listaHoteles.Count; i++)
                {
                    if (listaHoteles[i].Estado)
                    {
                        comboBox1.Items.Add(listaHoteles[i].ID + "-" + listaHoteles[i].Nombre + "-" + listaHoteles[i].Direccion);
                    }
                }
            }
            else
            {
                label2.Text = "Sin Hoteles Disponibles";
                comboBox1.Enabled = false;
                button1.Enabled = false;
                textBox1.Enabled = false;
                dateTimePicker1.Enabled = false;
            }
        }

        private void mostrarArticulos()
        {
            List<Articulo> listaArticulos = new List<Articulo>();
            listaArticulos = sentencias.ArticulosRegistrados();
            if (listaArticulos.Count != 0)
            {
                button1.Enabled = true;
                textBox1.Enabled = true;
                dateTimePicker1.Enabled = true;
                dataGridView1.DataSource = listaArticulos;
                dataGridView1.Columns["IdCategoria"].Visible = false;
                foreach (DataGridViewColumn columna in dataGridView1.Columns)
                {
                    columna.Resizable = DataGridViewTriState.False;
                }
                label3.Text = "ARTICULOS REGISTRADOS";
            }
            else
            {
                label3.Text = "NO HAY ARTICULOS REGISTRADOS";
                button1.Enabled = false;
                textBox1.Enabled = false;
                dateTimePicker1.Enabled = false;
            }
        }

        private void articulosAsignados()
        {
            string[] infoHotel = comboBox1.SelectedItem.ToString().Split('-');
            int IdHotel = int.Parse(infoHotel[0]);
            List<Articulo> listaArticulos = sentencias.ArticulosAsignados(IdHotel);
            if (listaArticulos.Count != 0)
            {
                dataGridView2.DataSource = listaArticulos;
                foreach (DataGridViewColumn columna in dataGridView2.Columns)
                {
                    columna.Resizable = DataGridViewTriState.False;
                }
                label6.Text = "ARTICULOS ASIGNADOS AL HOTEL";
            }
            else
            {
                label6.Text = "NO HAY ARTICULOS ASIGNADOS AL HOTEL";
            }
        }

        private ArticuloHotel llenarInformacion()
        {
            try
            {
                int ID = int.Parse(textBox1.Text);
                DateTime fecha = dateTimePicker1.Value;
                string[] infoHotel = comboBox1.SelectedItem.ToString().Split('-');
                int IdHotel = int.Parse(infoHotel[0]);
                Hotel hotel = sentencias.ObtenerHotel(IdHotel);
                ArticuloHotel articuloHotel = new ArticuloHotel();
                articuloHotel.IdAsignacion = ID;
                articuloHotel.FechaAfiliacion = fecha;
                articuloHotel.InfoHotel = hotel;
                return articuloHotel;
            }
            catch (FormatException)
            {
                MessageBox.Show("Error en el campo ID");
            }
            return null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                ArticuloHotel articuloHotel = llenarInformacion();
                if (articuloHotel != null)
                {
                    foreach (DataGridViewRow selectedRow in dataGridView1.SelectedRows)
                    {
                        Articulo articulo = new Articulo();
                        articulo.ID = int.Parse(selectedRow.Cells[0].Value.ToString());
                        articuloHotel.ArticuloAsignado = articulo;
                        sentencias.AgregarArticuloHotel(articuloHotel);
                    }
                    articulosAsignados();
                }
            }
            else
            {
                MessageBox.Show("Seleccione por lo menos 1 Articulo");
            }
            textBox1.Text = "";
            dataGridView1.Columns.Clear();
            mostrarArticulos();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            principal.Visible = true;
            this.Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label6.Text = "";
            dataGridView2.Columns.Clear();
            if (comboBox1.SelectedIndex != 0)
            {
                mostrarArticulos();
                articulosAsignados();
            }
            else
            {
                button1.Enabled = false;
                textBox1.Enabled = false;
                dateTimePicker1.Enabled = false;
            }
        }

        private void RegistrarArticuloHotel_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (principal.estado)
                {
                    e.Cancel = true;
                    MessageBox.Show("Debe volver a la ventana principal y desconectar el servidor");
                }
            }
        }
    }
}
