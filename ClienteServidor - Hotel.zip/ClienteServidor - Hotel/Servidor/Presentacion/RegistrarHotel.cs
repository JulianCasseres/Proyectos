﻿using System;
using System.Windows.Forms;
using Entidades;
using SentenciasSQL;

namespace Presentacion
{
    public partial class RegistrarHotel : Form
    {
        Principal principal;
        Sentencias sentencias = new Sentencias();

        public RegistrarHotel(Principal principal)
        {
            InitializeComponent();
            this.principal = principal;
            comboBox1.SelectedIndex = 0;
        }

        private bool ValidarDatos(int id, string nombre, string direccion, string estado, string telefono)
        {
            if (sentencias.ObtenerHotel(id) != null)
            {
                return false;
            }

            if (string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(direccion) || string.IsNullOrEmpty(telefono))
            {
                return false;
            }

            if (!estado.Equals("Activo") && !estado.Equals("Inactivo"))
            {
                return false;
            }
            return true;
        }

        private Hotel LlenarInformacion()
        {
            try
            {
                int ID = int.Parse(textBox1.Text);
                string direccion = textBox2.Text;
                string telefono = textBox3.Text;
                string nombre = textBox4.Text;
                string estado = comboBox1.SelectedItem.ToString();

                if (ValidarDatos(ID, nombre, direccion, estado, telefono))
                {
                    Hotel hotel = new Hotel();
                    if (estado.Equals("Activo"))
                    {
                        hotel.ID = ID;
                        hotel.Nombre = nombre;
                        hotel.Direccion = direccion;
                        hotel.Telefono = telefono;
                        hotel.Estado = true;
                    }
                    else
                    {
                        hotel.ID = ID;
                        hotel.Nombre = nombre;
                        hotel.Direccion = direccion;
                        hotel.Telefono = telefono;
                        hotel.Estado = false;
                    }
                    return hotel;
                }
            }
            catch (FormatException){}
            MessageBox.Show("Por favor, verifique lo siguiente:" +
                            "\n - Asegúrese de que el Id NO se repita." +
                            "\n - Asegúrese de que ningun campo está vacío." +
                            "\n - Asegúrese de que el campo Id contenga solo caracteres numéricos." +
                            "\n - Asegúrese de que el estado sea 'Activo' o 'Inactivo'.");
            return null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Hotel hotel = LlenarInformacion();
            if (hotel != null)
            {
                sentencias.AgregarHotel(hotel);
                MessageBox.Show("Hotel Guardado");
            }
            textBox1.Text = ""; textBox2.Text = "";
            textBox3.Text = ""; textBox4.Text = "";
            comboBox1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            principal.Visible = true;
            this.Visible = false;
        }

        private void RegistrarHotel_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (principal.estado)
                {
                    e.Cancel = true;
                    MessageBox.Show("Debe volver a la ventana principal y desconectar el servidor");
                }
            }
        }
    }
}
