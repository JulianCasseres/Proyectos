﻿using Entidades;
using SentenciasSQL;
using System;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class RegistrarArticulo : Form
    {
        Principal principal;
        Sentencias sentencias = new Sentencias();

        public RegistrarArticulo(Principal principal)
        {
            InitializeComponent();
            this.principal = principal;
        }

        private bool ValidarDatos(int id, string nombre, int precio)
        {
            if (sentencias.ObtenerArticulo(id) != null)
            {
                return false;
            }

            if (string.IsNullOrEmpty(nombre) || precio < 0)
            {
                return false;
            }
            return true;
        }

        private Articulo LlenarInformacion()
        {
            try
            {
                int ID = int.Parse(textBox1.Text);
                string nombre = textBox2.Text;
                int idCategoria = int.Parse(textBox3.Text);
                int precio = int.Parse(textBox4.Text); 

                if (ValidarDatos(ID, nombre, precio))
                {
                    if (sentencias.ObtenerCategoriaArticulo(idCategoria) != null)
                    {
                        Articulo articulo = new Articulo();
                        articulo.ID = ID;
                        articulo.Nombre = nombre;
                        articulo.IdCategoria = idCategoria;
                        articulo.Precio = precio;
                        return articulo;
                    }
                    else
                    {
                        MessageBox.Show("Asegúrese de que el campo 'IdCategoria' exista");
                        return null;
                    }
                }
            }
            catch (FormatException){}
            MessageBox.Show("Por favor, verifique lo siguiente:" +
                            "\n - Asegúrese de que el campo 'Id' NO se repita y solo contenga caracteres numéricos." +
                            "\n - Asegúrese de que ningun campo está vacío." +
                            "\n - Asegúrese de que el campo 'IdCategoria' contenga solo caracteres numéricos." +
                            "\n - Asegúrese de que el estado sea 'Activo' o 'Inactivo'." +
                            "\n - Asegúrese de que el campo 'Precio' contenga solo caracteres numerico y sea mayor a 0.");
            return null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Articulo articulo = LlenarInformacion();
            if (articulo != null)
            {
                sentencias.AgregarArticulo(articulo);
                MessageBox.Show("Articulo Guardado");
            }
            textBox1.Text = ""; textBox2.Text = "";
            textBox3.Text = ""; textBox4.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            principal.Visible = true;
            this.Visible = false;
        }

        private void RegistrarArticulo_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (principal.estado)
                {
                    e.Cancel = true;
                    MessageBox.Show("Debe volver a la ventana principal y desconectar el servidor");
                }
            }
        }
    }
}
