﻿using Entidades;
using SentenciasSQL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class ConsultarClientes : Form
    {
        Principal principal;
        Sentencias sentecia = new Sentencias();

        public ConsultarClientes(Principal principal)
        {
            InitializeComponent();
            this.principal = principal;
            mostrarClientes();
        }

        private void mostrarClientes()
        {
            List<Cliente> ListaClientes = new List<Cliente>();
            ListaClientes = sentecia.ClientesRegistrados();
            if (ListaClientes.Count != 0)
            {
                dataGridView1.DataSource = ListaClientes;
                dataGridView1.Columns["PrimerApellido"].HeaderText = "Apellido1";
                dataGridView1.Columns["SegundoApellido"].HeaderText = "Apellido2";
                dataGridView1.Columns["FechaNacimiento"].HeaderText = "Nacimiento";
                foreach (DataGridViewColumn columna in dataGridView1.Columns)
                {
                    columna.Resizable = DataGridViewTriState.False;
                }
                for (int i=0; i<ListaClientes.Count; i++)
                {
                    dataGridView1.Rows[i].Cells[4].Value = ListaClientes[i].FechaNacimiento.ToShortDateString();
                }
                label2.Text = "Clientes registrados: " + ListaClientes.Count;
            }
            else
            {
                label2.Text = "No hay clientes registrados";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            principal.Visible = true;
            this.Visible = false;
        }

        private void ConsultarClientes_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (principal.estado)
                {
                    e.Cancel = true;
                    MessageBox.Show("Debe volver a la ventana principal y desconectar el servidor");
                }
            }
        }
    }
}
