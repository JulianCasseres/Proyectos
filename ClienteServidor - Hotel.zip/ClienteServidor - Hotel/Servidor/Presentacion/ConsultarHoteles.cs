﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using SentenciasSQL;
using System.Configuration;

namespace Presentacion
{
    public partial class ConsultarHoteles : Form
    {
        Principal principal;
        Sentencias sentecia = new Sentencias();

        public ConsultarHoteles(Principal principal)
        {
            InitializeComponent();
            this.principal = principal;
            mostrarHoteles();
        }

        private void mostrarHoteles()
        {
            List<Hotel> ListaHoteles = new List<Hotel>();
            ListaHoteles = sentecia.HotelesRegistrados();
            if (ListaHoteles.Count != 0)
            {
                dataGridView1.DataSource = ListaHoteles;
                foreach (DataGridViewColumn columna in dataGridView1.Columns)
                {
                    columna.Resizable = DataGridViewTriState.False;
                }
                label2.Text = "Hoteles registrados: " + ListaHoteles.Count;
            }
            else
            {
                label2.Text = "No hay hoteles registrados";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            principal.Visible = true;
            this.Visible = false;
        }

        private void ConsultarHoteles_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (principal.estado)
                {
                    e.Cancel = true;
                    MessageBox.Show("Debe volver a la ventana principal y desconectar el servidor");
                }
            }
        }
    }
}
