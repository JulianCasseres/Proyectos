﻿using Entidades;
using SentenciasSQL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentacion
{
    public partial class ConsultarArticulos : Form
    {
        Principal principal;
        Sentencias sentecias = new Sentencias();

        public ConsultarArticulos(Principal principal)
        {
            InitializeComponent();
            this.principal = principal;
            mostrarArticulos();
        }

        private void mostrarArticulos()
        {
            List<Articulo> ListaArticulos = new List<Articulo>();
            ListaArticulos = sentecias.ArticulosRegistrados();
            if (ListaArticulos.Count != 0)
            {
                dataGridView1.DataSource = ListaArticulos;
                foreach (DataGridViewColumn columna in dataGridView1.Columns)
                {
                    columna.Resizable = DataGridViewTriState.False;
                }
                label2.Text = "Articulos registrados: " + ListaArticulos.Count;
            }
            else
            {
                label2.Text = "No hay articulos registrados";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            principal.Visible = true;
            this.Visible = false;
        }

        private void ConsultarArticulos_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (principal.estado)
                {
                    e.Cancel = true;
                    MessageBox.Show("Debe volver a la ventana principal y desconectar el servidor");
                }
            }
        }
    }
}
