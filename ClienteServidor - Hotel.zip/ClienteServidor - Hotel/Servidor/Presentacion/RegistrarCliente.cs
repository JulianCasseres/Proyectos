﻿using System;
using System.Windows.Forms;
using Entidades;
using SentenciasSQL;

namespace Presentacion
{
    public partial class RegistrarCliente : Form
    {
        Principal principal;
        Sentencias sentencias = new Sentencias();

        public RegistrarCliente(Principal principal)
        {
            InitializeComponent();
            this.principal = principal;
            comboBox1.SelectedIndex = 0;
        }

        private bool ValidarDatos(string identificacion, string nombre, string apellido1, string apellido2)
        {
            if(sentencias.ObtenerCliente(identificacion) != null)
            {
                return false;
            }

            if (string.IsNullOrEmpty(identificacion) || string.IsNullOrEmpty(nombre) || string.IsNullOrEmpty(apellido1) || string.IsNullOrEmpty(apellido2))
            {
                return false;
            }

            if (comboBox1.SelectedIndex == 0)
            {
                return false;
            }
            return true;
        }

        private Cliente LlenarInformacion()
        {
            string identificacion = textBox1.Text;
            string nombre = textBox2.Text;
            string apellido1 = textBox3.Text;
            string apellido2 = textBox4.Text;
            DateTime nacimiento = dateTimePicker1.Value;
            char genero = comboBox1.SelectedItem.ToString()[0];

            if (ValidarDatos(identificacion, nombre, apellido1, apellido2))
            {
                Cliente cliente = new Cliente();
                cliente.Identificacion = identificacion;
                cliente.Nombre = nombre;
                cliente.PrimerApellido = apellido1;
                cliente.SegundoApellido = apellido2;
                cliente.FechaNacimiento = nacimiento;
                cliente.Genero = genero;
                return cliente;
            }
            else
            {
                MessageBox.Show("Por favor, verifique lo siguiente:" +
                                "\n - Asegúrese de que la Identificacion NO se repita." +
                                "\n - Asegúrese de que ningun campo está vacío." +
                                "\n - Asegúrese de que el genero sea 'Masculino' o 'Femenino'.");
            }
            return null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cliente cliente = LlenarInformacion();
            if (cliente != null)
            {
                sentencias.AgregarCliente(cliente);
                MessageBox.Show("Cliente Guardado");
            }
            textBox1.Text = ""; textBox2.Text = "";
            textBox3.Text = ""; textBox4.Text = "";
            comboBox1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            principal.Visible = true;
            this.Visible = false;
        }

        private void RegistrarCliente_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (principal.estado)
                {
                    e.Cancel = true;
                    MessageBox.Show("Debe volver a la ventana principal y desconectar el servidor");
                }
            }
        }
    }
}
