﻿using Entidades;
using SentenciasSQL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace Presentacion
{
    public partial class ConsultarArticulosHotel : Form
    {
        Principal principal;
        Sentencias sentencias = new Sentencias();

        public ConsultarArticulosHotel(Principal principal)
        {
            InitializeComponent();
            this.principal = principal;
            agregarHoteles();
            comboBox1.SelectedIndex = 0;
        }

        private void agregarHoteles()
        {
            List<Hotel> listaHoteles = sentencias.HotelesDisponibles();
            if (listaHoteles.Count != 0)
            {
                label2.Text = "Hoteles Disponibles";
                for (int i = 0; i < listaHoteles.Count; i++)
                {
                    if (listaHoteles[i].Estado)
                    {
                        comboBox1.Items.Add(listaHoteles[i].ID + "-" + listaHoteles[i].Nombre + "-" + listaHoteles[i].Direccion);
                    }
                }
            }
            else
            {
                label2.Text = "Sin Hoteles Disponibles";
                comboBox1.Enabled = false;
            }
        }

        private void articulosAsignados()
        {
            string[] infoHotel = comboBox1.SelectedItem.ToString().Split('-');
            int IdHotel = int.Parse(infoHotel[0]);
            List<ArticuloHotel> listaAsignados = sentencias.ArticulosAsignadosHotel(IdHotel);
            if (listaAsignados.Count != 0)
            {
                foreach (DataGridViewColumn columna in dataGridView2.Columns)
                {
                    columna.Resizable = DataGridViewTriState.False;
                }

                for (int i = 0; i < listaAsignados.Count; i++)
                {
                    dataGridView2.Rows.Add();
                    dataGridView2.Rows[i].Cells[0].Value = listaAsignados[i].IdAsignacion;
                    dataGridView2.Rows[i].Cells[1].Value = listaAsignados[i].FechaAfiliacion.ToShortDateString();
                    dataGridView2.Rows[i].Cells[2].Value = listaAsignados[i].ArticuloAsignado.ID;
                    dataGridView2.Rows[i].Cells[3].Value = listaAsignados[i].ArticuloAsignado.Nombre;
                    dataGridView2.Rows[i].Cells[4].Value = listaAsignados[i].ArticuloAsignado.Precio;
                }
                label6.Text = "ARTICULOS ASIGNADOS AL HOTEL";
            }
            else
            {
                label6.Text = "NO HAY ARTICULOS ASIGNADOS AL HOTEL";
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label6.Text = "";
            dataGridView2.Rows.Clear();
            if (comboBox1.SelectedIndex != 0)
            {
                articulosAsignados();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            principal.Visible = true;
            this.Visible = false;
        }

        private void ConsultarArticulosHotel_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (principal.estado)
                {
                    e.Cancel = true;
                    MessageBox.Show("Debe volver a la ventana principal y desconectar el servidor");
                }
            }
        }
    }
}
