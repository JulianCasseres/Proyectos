﻿using System;
using System.Windows.Forms;
using Entidades;
using SentenciasSQL;

namespace Presentacion
{
    public partial class RegistrarCategoria : Form
    {
        Principal principal;
        Sentencias sentencias = new Sentencias();

        public RegistrarCategoria(Principal principal)
        {
            InitializeComponent();
            this.principal = principal;
            comboBox1.SelectedIndex = 0;
        }

        private bool ValidarDatos(int id, string descripcion, string estado)
        {
            if (sentencias.ObtenerCategoriaArticulo(id) != null)
            {
                return false;
            }

            if (string.IsNullOrEmpty(descripcion))
            {
                return false;
            }

            if (!estado.Equals("Activo") && !estado.Equals("Inactivo"))
            {
                return false;
            }
            return true;
        }

        private CategoriaArticulo LlenarInformacion()
        {
            try
            {
                int ID = int.Parse(textBox1.Text);
                string descripcion = textBox2.Text;
                string estado = comboBox1.SelectedItem.ToString();

                if (ValidarDatos(ID, descripcion, estado))
                {
                    CategoriaArticulo categoria = new CategoriaArticulo();
                    if (estado.Equals("Activo"))
                    {
                        categoria.ID = ID;
                        categoria.Descripcion = descripcion;
                        categoria.Estado = true;
                    }
                    else
                    {
                        categoria.ID = ID;
                        categoria.Descripcion = descripcion;
                        categoria.Estado = false;
                    }
                    return categoria;
                }
            }
            catch (FormatException){}
            MessageBox.Show("Por favor, verifique lo siguiente:" +
                            "\n - Asegúrese de que el Id NO se repita." +
                            "\n - Asegúrese de que ningun campo está vacío." +
                            "\n - Asegúrese de que el campo Id contenga solo caracteres numéricos." +
                            "\n - Asegúrese de que el estado sea 'Activo' o 'Inactivo'.");
            return null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CategoriaArticulo categoria = LlenarInformacion();
            if (categoria != null)
            {
                sentencias.AgregarCategoria(categoria);
                MessageBox.Show("Categoria Guardada");
            }
            textBox1.Text = ""; textBox2.Text = "";
            comboBox1.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            principal.Visible = true;
            this.Visible = false;
        }

        private void RegistrarCategoria_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (principal.estado)
                {
                    e.Cancel = true;
                    MessageBox.Show("Debe volver a la ventana principal y desconectar el servidor");
                }
            }
        }
    }
}
