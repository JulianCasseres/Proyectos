﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Entidades;
using System.Configuration;
using System.Windows.Forms;

namespace SentenciasSQL
{
    public class Sentencias
    {
        private string cadenaConexion;
        static List<string> ClientesConectados = new List<string>();
        static SemaphoreSlim semaforoAccesoBaseDatos = new SemaphoreSlim(1);

        public Sentencias()
        {
            cadenaConexion = ConfigurationManager.ConnectionStrings["conexionRESORTSUNED"].ConnectionString;
        }

        public void Conectar(string identificacion)
        {
            ClientesConectados.Add(identificacion);
        }

        public void Desconectar(string identificacion)
        {
            ClientesConectados.Remove(identificacion);
        }

        #region SentenciasHotel
        public List<Hotel> HotelesRegistrados()
        {
            List<Hotel> listaHoteles = new List<Hotel>();
            string sentencia = "SELECT * FROM Hotel";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.CommandType = CommandType.Text;
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Hotel hotel = new Hotel();
                                    hotel.ID = reader.GetInt32(0);
                                    hotel.Nombre = reader.GetString(1);
                                    hotel.Direccion = reader.GetString(2);
                                    hotel.Estado = reader.GetBoolean(3);
                                    hotel.Telefono = reader.GetString(4);
                                    listaHoteles.Add(hotel);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener los hoteles registrados en la base de datos: {ex.Message}");
            }
            return listaHoteles;
        }

        public Hotel ObtenerHotel(int ID)
        {
            Hotel hotel = new Hotel();
            string sentencia = "SELECT IdHotel, Nombre, Direccion, Estado, Telefono FROM Hotel WHERE IdHotel = @IdHotel";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.CommandType = CommandType.Text;
                        comando.Parameters.AddWithValue("@IdHotel", ID);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    hotel.ID = reader.GetInt32(0);
                                    hotel.Nombre = reader.GetString(1);
                                    hotel.Direccion = reader.GetString(2);
                                    hotel.Estado = reader.GetBoolean(3);
                                    hotel.Telefono = reader.GetString(4);
                                }
                            }
                            else
                            {
                                hotel = null;
                            }
                        }
                    }
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("Error al obtener el hotel con Id(" + ID + ") de la base de datos");
            }
            return hotel;
        }

        public void AgregarHotel(Hotel hotel)
        {
            string sentencia = "INSERT INTO Hotel (IdHotel, Nombre, Direccion, Estado, Telefono) VALUES (@IdHotel, @Nombre, @Direccion, @Estado, @Telefono)";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand())
                    {
                        comando.CommandType = CommandType.Text;
                        comando.CommandText = sentencia;
                        comando.Connection = conexion;
                        comando.Parameters.AddWithValue("@IdHotel", hotel.ID);
                        comando.Parameters.AddWithValue("@Nombre", hotel.Nombre);
                        comando.Parameters.AddWithValue("@Direccion", hotel.Direccion);
                        comando.Parameters.AddWithValue("@Estado", hotel.Estado);
                        comando.Parameters.AddWithValue("@Telefono", hotel.Telefono);

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al agregar el hotel en la base de datos: {ex.Message}");
            }
        }
        #endregion

        #region SentenciasCliente
        public List<Cliente> ClientesRegistrados()
        {
            List<Cliente> listaClientes = new List<Cliente>();
            string sentencia = "SELECT * FROM Cliente";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Cliente cliente = new Cliente();
                                    cliente.Identificacion = reader.GetString(0);
                                    cliente.Nombre = reader.GetString(1);
                                    cliente.PrimerApellido = reader.GetString(2);
                                    cliente.SegundoApellido = reader.GetString(3);
                                    cliente.FechaNacimiento = reader.GetDateTime(4);
                                    cliente.Genero = Convert.ToChar(reader.GetString(5));
                                    listaClientes.Add(cliente);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener los clientes registrados en la base de datos: {ex.Message}");
            }
            return listaClientes;
        }

        public Cliente ObtenerCliente(string identificacion)
        {
            Cliente cliente = new Cliente();
            string sentencia = "SELECT IdCliente, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento, Genero FROM Cliente WHERE IdCliente = @IdCliente";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.CommandType = CommandType.Text;
                        comando.Parameters.AddWithValue("@IdCliente", identificacion);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    cliente.Identificacion = reader.GetString(0);
                                    cliente.Nombre = reader.GetString(1);
                                    cliente.PrimerApellido = reader.GetString(2);
                                    cliente.SegundoApellido = reader.GetString(3);
                                    cliente.FechaNacimiento = reader.GetDateTime(4);
                                    cliente.Genero = Convert.ToChar(reader.GetString(5));
                                }
                            }
                            else
                            {
                                cliente = null;
                            }
                        }
                    }
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("Error al obtener el cliente con Identificacion(" + identificacion + ") de la base de datos");
            }
            return cliente;
        }

        public void AgregarCliente(Cliente cliente)
        {
            string sentencia = "INSERT INTO Cliente (IdCliente, Nombre, PrimerApellido, SegundoApellido, FechaNacimiento, Genero) VALUES (@IdCliente, @Nombre, @PrimerApellido, @SegundoApellido, @FechaNacimiento, @Genero)";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@IdCliente", cliente.Identificacion);
                        comando.Parameters.AddWithValue("@Nombre", cliente.Nombre);
                        comando.Parameters.AddWithValue("@PrimerApellido", cliente.PrimerApellido);
                        comando.Parameters.AddWithValue("@SegundoApellido", cliente.SegundoApellido);
                        comando.Parameters.AddWithValue("@FechaNacimiento", cliente.FechaNacimiento);
                        comando.Parameters.AddWithValue("@Genero", cliente.Genero);

                        comando.CommandType = CommandType.Text;
                        comando.Connection = conexion;

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al agregar el cliente en la base de datos: {ex.Message}");
            }
        }
        #endregion

        #region SentenciasCategoria
        public List<CategoriaArticulo> CategoriasRegistradas()
        {
            List<CategoriaArticulo> listaCategorias = new List<CategoriaArticulo>();
            string sentencia = "SELECT * FROM CategoriaArticulo";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    CategoriaArticulo categoria = new CategoriaArticulo();
                                    categoria.ID = reader.GetInt32(0);
                                    categoria.Descripcion = reader.GetString(1);
                                    categoria.Estado = reader.GetBoolean(2);
                                    listaCategorias.Add(categoria);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener las categorias registradas en la base de datos: {ex.Message}");
            }
            return listaCategorias;
        }

        public CategoriaArticulo ObtenerCategoriaArticulo(int ID)
        {
            CategoriaArticulo categoria = new CategoriaArticulo();
            string sentencia = "SELECT IdCategoria, Descripcion, Estado FROM CategoriaArticulo WHERE IdCategoria = @IdCategoria";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.CommandType = CommandType.Text;
                        comando.Parameters.AddWithValue("@IdCategoria", ID);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    categoria.ID = reader.GetInt32(0);
                                    categoria.Descripcion = reader.GetString(1);
                                    categoria.Estado = reader.GetBoolean(2);
                                }
                            }
                            else
                            {
                                categoria = null;
                            }
                        }
                    }
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("Error al obtener la categoria con Id(" + ID + ") de la base de datos");
            }
            return categoria;
        }

        public void AgregarCategoria(CategoriaArticulo categoria)
        {
            string sentencia = "INSERT INTO CategoriaArticulo (IdCategoria, Descripcion, Estado) VALUES (@IdCategoria, @Descripcion, @Estado)";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@IdCategoria", categoria.ID);
                        comando.Parameters.AddWithValue("@Descripcion", categoria.Descripcion);
                        comando.Parameters.AddWithValue("@Estado", categoria.Estado);

                        comando.CommandType = CommandType.Text;
                        comando.Connection = conexion;

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al agregar la categoria en la base de datos: {ex.Message}");
            }
        }
        #endregion

        #region SentenciasArticulo
        public List<Articulo> ArticulosRegistrados()
        {
            List<Articulo> listaArticulos = new List<Articulo>();
            string sentencia = "SELECT * FROM Articulo";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Articulo articulo = new Articulo();
                                    articulo.ID = reader.GetInt32(0);
                                    articulo.Nombre = reader.GetString(1);
                                    articulo.Precio = reader.GetInt32(3);
                                    articulo.IdCategoria = reader.GetInt32(2);
                                    listaArticulos.Add(articulo);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener los articulos registrados en la base de datos: {ex.Message}");
            }
            return listaArticulos;
        }

        public Articulo ObtenerArticulo(int ID)
        {
            Articulo articulo = new Articulo();
            string sentencia = "SELECT IdArticulo, Nombre, IdCategoria, Precio FROM Articulo WHERE IdArticulo = @IdArticulo";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.CommandType = CommandType.Text;
                        comando.Parameters.AddWithValue("@IdArticulo", ID);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    articulo.ID = reader.GetInt32(0);
                                    articulo.Nombre = reader.GetString(1);
                                    articulo.Precio = reader.GetInt32(3);
                                    articulo.IdCategoria = reader.GetInt32(2);
                                }
                            }
                            else
                            {
                                articulo = null;
                            }
                        }
                    }
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("Error al obtener el articulo con Id(" + ID + ") de la base de datos");
            }
            return articulo;
        }

        public void AgregarArticulo(Articulo articulo)
        {
            string sentencia = "INSERT INTO Articulo (IdArticulo, Nombre, IdCategoria, Precio) VALUES (@IdArticulo, @Nombre, @IdCategoria, @Precio)";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@IdArticulo", articulo.ID);
                        comando.Parameters.AddWithValue("@Nombre", articulo.Nombre);
                        comando.Parameters.AddWithValue("@IdCategoria", articulo.IdCategoria);
                        comando.Parameters.AddWithValue("@Precio", articulo.Precio);

                        comando.CommandType = CommandType.Text;
                        comando.Connection = conexion;

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al agregar el articulo en la base de datos: {ex.Message}");
            }
        }
        #endregion

        #region SentenciasArticuloHotel
        public void AgregarArticuloHotel(ArticuloHotel articuloHotel)
        {
            string sentencia = "INSERT INTO ArticuloHotel (IdAsignacion, IdHotel, IdArticulo, FechaAsignacion) VALUES (@IdAsignacion, @IdHotel, @IdArticulo, @FechaAsignacion)";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@IdAsignacion", articuloHotel.IdAsignacion);
                        comando.Parameters.AddWithValue("@IdHotel", articuloHotel.InfoHotel.ID);
                        comando.Parameters.AddWithValue("@FechaAsignacion", articuloHotel.FechaAfiliacion);
                        comando.Parameters.AddWithValue("@IdArticulo", articuloHotel.ArticuloAsignado.ID);

                        comando.CommandType = CommandType.Text;
                        comando.Connection = conexion;

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                    MessageBox.Show("Articulo(" + articuloHotel.ArticuloAsignado.ID + ") asignado correctamente");
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("El articulo(" + articuloHotel.ArticuloAsignado.ID + ") ya está asignado por ende se omitirá la asignación");
            }
        }

        public List<Hotel> HotelesDisponibles()
        {
            List<Hotel> listaHoteles = new List<Hotel>();
            string sentencia = "SELECT IdHotel, Nombre, Direccion, Estado, Telefono FROM Hotel WHERE Estado = @Estado";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@Estado", true);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Hotel hotel = new Hotel();
                                    hotel.ID = reader.GetInt32(0);
                                    hotel.Nombre = reader.GetString(1);
                                    hotel.Direccion = reader.GetString(2);
                                    hotel.Estado = reader.GetBoolean(3);
                                    hotel.Telefono = reader.GetString(4);
                                    listaHoteles.Add(hotel);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener los hoteles activos: {ex.Message}");
            }

            return listaHoteles;
        }

        public List<Articulo> ArticulosAsignados(int IdHotel)
        {
            List<Articulo> listaArticulos = new List<Articulo>();
            string sentencia = "SELECT A.IdArticulo, A.Nombre, A.IdCategoria, A.Precio FROM ArticuloHotel AH " +
                                "INNER JOIN Hotel H ON AH.IdHotel = H.IdHotel " +
                                "INNER JOIN Articulo A ON AH.IdArticulo = A.IdArticulo " +
                                "WHERE AH.IdHotel = @IdHotel";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@IdHotel", IdHotel);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Articulo articulo = new Articulo();
                                    articulo.ID = reader.GetInt32(0);
                                    articulo.Nombre = reader.GetString(1);
                                    articulo.IdCategoria = reader.GetInt32(2);
                                    articulo.Precio = reader.GetInt32(3);
                                    listaArticulos.Add(articulo);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("Error al obtener los articulos asignados al hotel(" + IdHotel + ")");
            }
            return listaArticulos;
        }

        public List<ArticuloHotel> ArticulosAsignadosHotel(int IdHotel)
        {
            List<ArticuloHotel> listaAsignados = new List<ArticuloHotel>();
            string sentencia = "SELECT AH.IdAsignacion, AH.FechaAsignacion, A.IdArticulo, A.Nombre, A.Precio FROM ArticuloHotel AH " +
                                "INNER JOIN Hotel H ON AH.IdHotel = H.IdHotel " +
                                "INNER JOIN Articulo A ON AH.IdArticulo = A.IdArticulo " +
                                "WHERE AH.IdHotel = @IdHotel";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@IdHotel", IdHotel);
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    ArticuloHotel informacion = new ArticuloHotel();
                                    informacion.IdAsignacion = reader.GetInt32(0);
                                    informacion.FechaAfiliacion = reader.GetDateTime(1);

                                    Articulo articulo = new Articulo();
                                    articulo.ID = reader.GetInt32(2);
                                    articulo.Nombre = reader.GetString(3);
                                    articulo.Precio = reader.GetInt32(4);
                                    
                                    informacion.ArticuloAsignado = articulo;
                                    listaAsignados.Add(informacion);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error al obtener los articulos asignados al hotel: {ex.Message}");
            }
            return listaAsignados;
        }
        #endregion

        #region SentenciasPedidos
        public bool AgregarPedido(Pedido pedido)
        {
            string sentencia = "INSERT INTO Pedido (IdPedido, IdCliente, IdArticulo, FechaPedido) VALUES (@IdPedido, @IdCliente, @IdArticulo, @FechaPedido)";
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@IdPedido", pedido.ID);
                        comando.Parameters.AddWithValue("@IdCliente", pedido.IdCliente);
                        comando.Parameters.AddWithValue("@IdArticulo", pedido.articulo.ID);
                        comando.Parameters.AddWithValue("@FechaPedido", pedido.Fecha);

                        comando.CommandType = CommandType.Text;
                        comando.Connection = conexion;

                        conexion.Open();
                        comando.ExecuteNonQuery();
                    }
                    MessageBox.Show("Articulo(" + pedido.articulo.ID + ") asignado correctamente");
                    return true;
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("El articulo(" + pedido.articulo.ID + ") ya está asginado con el Id( " + pedido.ID + "), se omitirá la asignación");
            }
            return false;
        }

        public List<Pedido> ConsultarPedidos(string IdCliente)
        {
            List<Pedido> listaPedidos = new List<Pedido>();
            string sentencia = "SELECT P.IdPedido, P.FechaPedido, A.IdArticulo, A.Nombre, A.Precio FROM Pedido P " +
                                "INNER JOIN Cliente C ON P.IdCliente = C.IdCliente " +
                                "INNER JOIN Articulo A ON P.IdArticulo = A.IdArticulo " +
                                "WHERE P.IdCliente = @IdCliente";

            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    using (SqlCommand comando = new SqlCommand(sentencia, conexion))
                    {
                        comando.Parameters.AddWithValue("@IdCliente", int.Parse(IdCliente));
                        conexion.Open();

                        using (SqlDataReader reader = comando.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    Pedido pedido = new Pedido();
                                    Articulo articulo = new Articulo();
                                    pedido.ID = reader.GetInt32(0);
                                    pedido.Fecha = reader.GetDateTime(1);
                                    articulo.ID = reader.GetInt32(2);
                                    articulo.Nombre = reader.GetString(3);
                                    articulo.Precio = reader.GetInt32(4);
                                    pedido.articulo = articulo;
                                    listaPedidos.Add(pedido);
                                }
                            }
                        }
                    }
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("Error al obtener los pedidos asignados al cliente(" + IdCliente + ")");
            }
            return listaPedidos;
        }
        #endregion
    }
}
