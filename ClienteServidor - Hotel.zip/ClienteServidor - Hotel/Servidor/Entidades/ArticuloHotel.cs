﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    [Serializable]
    public class ArticuloHotel
    {
        public int IdAsignacion { get; set; }
        public DateTime FechaAfiliacion { get; set; }
        public Hotel InfoHotel { get; set; }
        public Articulo ArticuloAsignado { get; set; }
    }
}
