﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Entidades;

namespace Presentacion
{
    public class TCP
    {
        private static IPAddress ipServidor;
        private static TcpClient cliente;
        private static IPEndPoint serverEndPoint;
        private static StreamWriter clienteStreamWriter;
        private static StreamReader clienteStreamReader;

        public static bool ConectarCliente(string identificacion)
        {
            try
            {
                ipServidor = IPAddress.Parse("127.0.0.1");
                cliente = new TcpClient();
                serverEndPoint = new IPEndPoint(ipServidor, 13200);
                cliente.Connect(serverEndPoint);

                Socket<string> solicitud = new Socket<string>
                {
                    Metodo = "ConectarCliente",
                    Entidad = identificacion
                };

                clienteStreamReader = new StreamReader(cliente.GetStream());
                clienteStreamWriter = new StreamWriter(cliente.GetStream());
                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(solicitud));
                clienteStreamWriter.Flush();
            }
            catch (SocketException)
            {
                return false;
            }
            return true;
        }

        public static void DesconectarCliente(string identificacion)
        {
            try
            {
                Socket<string> solicitud = new Socket<string>
                {
                    Metodo = "DesconectarCliente",
                    Entidad = identificacion
                };
                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(solicitud));
                clienteStreamWriter.Flush();
            }
            catch (IOException)
            {
                // Manejar cualquier error de E/S
            }
            finally
            {
                cliente.Close();
            }
        }

        public static bool EstadoConexion(string identificacion)
        {
            bool estado = true;
            try
            {
                Socket<string> solicitud = new Socket<string>
                {
                    Metodo = "EstadoConexion",
                    Entidad = identificacion
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(solicitud));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                estado = JsonConvert.DeserializeObject<bool>(respuesta);
            }
            catch (Exception) { estado = false; }

            return estado;
        }

        public static Cliente ObtenerCliente(string identificacion)
        {
            Cliente cliente = new Cliente();

            try
            {
                Socket<string> solicitud = new Socket<string>
                {
                    Metodo = "ObtenerCliente",
                    Entidad = identificacion
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(solicitud));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                cliente = JsonConvert.DeserializeObject<Cliente>(respuesta);
            }
            catch (Exception){ cliente = null; }

            return cliente;
        }

        public static List<Hotel> HotelesDisponibles()
        {
            List<Hotel> listaHoteles = new List<Hotel>();
            try
            {
                Socket<string> solicitud = new Socket<string>
                {
                    Metodo = "HotelesDisponibles"
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(solicitud));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                listaHoteles = JsonConvert.DeserializeObject<List<Hotel>>(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener los hoteles activos registrados: " + ex.Message);
            }

            return listaHoteles;
        }

        public static List<ArticuloHotel> ArticulosAsignados(int IdHotel)
        {
            List<ArticuloHotel> listaArticulos = new List<ArticuloHotel>();

            try
            {
                Socket<string> solicitud = new Socket<string>
                {
                    Metodo = "ArticulosAsignados",
                    Entidad = IdHotel.ToString()
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(solicitud));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                listaArticulos = JsonConvert.DeserializeObject<List<ArticuloHotel>>(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener los articulos asignados al hotel: " + ex.Message);
            }

            return listaArticulos;
        }

        public static void AgregarPedido(Pedido pedido)
        {
            try
            {
                Socket<Pedido> solicitud = new Socket<Pedido>
                {
                    Metodo = "AgregarPedido",
                    Entidad = pedido
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(solicitud));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                pedido = JsonConvert.DeserializeObject<Pedido>(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al agregar el pedido: " + ex.Message);
            }
        }

        public static List<Pedido> ConsultarPedidos(string identificacion)
        {
            List<Pedido> listaPedidos = new List<Pedido>();

            try
            {
                Socket<string> solicitud = new Socket<string>
                {
                    Metodo = "ConsultarPedidos",
                    Entidad = identificacion
                };

                clienteStreamWriter.WriteLine(JsonConvert.SerializeObject(solicitud));
                clienteStreamWriter.Flush();

                var respuesta = clienteStreamReader.ReadLine();
                listaPedidos = JsonConvert.DeserializeObject<List<Pedido>>(respuesta);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener el/los pedido/s del cliente: " + ex.Message);
            }

            return listaPedidos;
        }
    }
}
