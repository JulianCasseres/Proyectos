﻿using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Presentacion
{
    public partial class ConsultarPedidos : Form
    {
        Principal principal;
        Cliente cliente;

        public ConsultarPedidos(Cliente cliente, Principal principal)
        {
            InitializeComponent();
            this.principal = principal;
            this.cliente = cliente;
            informacionCliente();
            consultarPedidos();
        }

        private void informacionCliente()
        {
            label1.Text = cliente.Nombre + " " + cliente.PrimerApellido + " " + cliente.SegundoApellido;
        }

        private void consultarPedidos()
        {
            double total = 0;
            List<Pedido> listaPedidos = TCP.ConsultarPedidos(cliente.Identificacion);
            if (listaPedidos.Count != 0)
            {
                foreach (DataGridViewColumn columna in dataGridView2.Columns)
                {
                    columna.Resizable = DataGridViewTriState.False;
                }

                for (int i = 0; i < listaPedidos.Count; i++)
                {
                    dataGridView2.Rows.Add();
                    dataGridView2.Rows[i].Cells[0].Value = listaPedidos[i].ID;
                    dataGridView2.Rows[i].Cells[1].Value = listaPedidos[i].Fecha.ToShortDateString();
                    dataGridView2.Rows[i].Cells[2].Value = listaPedidos[i].articulo.ID;
                    dataGridView2.Rows[i].Cells[3].Value = listaPedidos[i].articulo.Nombre;
                    dataGridView2.Rows[i].Cells[4].Value = listaPedidos[i].articulo.Precio;
                    total += listaPedidos[i].articulo.Precio;
                }
                label6.Text = "PEDIDOS REALIZADOS POR EL CLIENTE";
            }
            else
            {
                label6.Text = "NO HAY PEDIDOS REALIZADOS POR EL CLIENTE";
            }
            label2.Text = "Total: $" + total;
        }

        private void ConsultarPedidos_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                TCP.DesconectarCliente(cliente.Identificacion);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            principal.Visible = true;
            this.Visible = false;
        }
    }
}
