﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Presentacion
{
    public partial class RealizarPedido : Form
    {
        Principal principal;
        Cliente cliente;

        public RealizarPedido(Cliente cliente, Principal principal)
        {
            InitializeComponent();
            this.principal = principal;
            this.cliente = cliente;
            comboBox1.SelectedIndex = 0;
            button1.Enabled = false;
            informacionCliente();
            agregarHoteles();
        }

        private void informacionCliente()
        {
            label1.Text = cliente.Nombre + " " + cliente.PrimerApellido + " " + cliente.SegundoApellido;
        }

        private void agregarHoteles()
        {
            List<Hotel> listaHoteles = TCP.HotelesDisponibles();
            if (listaHoteles.Count != 0)
            {
                label2.Text = "Hoteles Disponibles";
                for (int i = 0; i < listaHoteles.Count; i++)
                {
                    if (listaHoteles[i].Estado)
                    {
                        comboBox1.Items.Add(listaHoteles[i].ID + "-" + listaHoteles[i].Nombre + "-" + listaHoteles[i].Direccion);
                    }
                }
            }
            else
            {
                label2.Text = "Sin Hoteles Disponibles";
                comboBox1.Enabled = false;
            }
        }

        private void articulosAsignados()
        {
            string[] infoHotel = comboBox1.SelectedItem.ToString().Split('-');
            int IdHotel = int.Parse(infoHotel[0]);
            List<ArticuloHotel> listaAsignados = TCP.ArticulosAsignados(IdHotel);
            if (listaAsignados.Count != 0)
            {
                foreach (DataGridViewColumn columna in dataGridView2.Columns)
                {
                    columna.Resizable = DataGridViewTriState.False;
                }

                for (int i = 0; i < listaAsignados.Count; i++)
                {
                    dataGridView2.Rows.Add();
                    dataGridView2.Rows[i].Cells[0].Value = listaAsignados[i].IdAsignacion;
                    dataGridView2.Rows[i].Cells[1].Value = listaAsignados[i].FechaAfiliacion.ToShortDateString();
                    dataGridView2.Rows[i].Cells[2].Value = listaAsignados[i].ArticuloAsignado.ID;
                    dataGridView2.Rows[i].Cells[3].Value = listaAsignados[i].ArticuloAsignado.Nombre;
                    dataGridView2.Rows[i].Cells[4].Value = listaAsignados[i].ArticuloAsignado.Precio;
                }
                label6.Text = "ARTICULOS ASIGNADOS AL HOTEL";
            }
            else
            {
                label6.Text = "NO HAY ARTICULOS ASIGNADOS AL HOTEL";
                button1.Enabled = false;
                textBox1.Enabled = false;
                dateTimePicker1.Enabled = false;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            label6.Text = "";
            dataGridView2.Rows.Clear();
            if (comboBox1.SelectedIndex != 0)
            {
                button1.Enabled = true;
                textBox1.Enabled = true;
                dateTimePicker1.Enabled = true;
                articulosAsignados();
            }
            else
            {
                button1.Enabled = false;
                textBox1.Enabled = false;
                dateTimePicker1.Enabled = false;
            }
        }

        private void RealizarPedido_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                TCP.DesconectarCliente(cliente.Identificacion);
            }
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            principal.Visible = true;
            this.Visible = false;
        }

        private void button1_Click(object sender, System.EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                try
                {
                    int ID = int.Parse(textBox1.Text);
                    int IdCliente = int.Parse(cliente.Identificacion);
                    foreach (DataGridViewRow selectedRow in dataGridView2.SelectedRows)
                    {
                        Pedido pedido = new Pedido();
                        pedido.ID = ID;
                        pedido.Fecha = dateTimePicker1.Value;
                        pedido.IdCliente = IdCliente;
                        pedido.articulo.ID = int.Parse(selectedRow.Cells[2].Value.ToString());
                        pedido.articulo.Nombre = selectedRow.Cells[3].Value.ToString();
                        pedido.articulo.Precio = int.Parse(selectedRow.Cells[4].Value.ToString());
                        TCP.AgregarPedido(pedido);
                    }
                }
                catch (FormatException) { }
            }
            else
            {
                MessageBox.Show("Por favor, verifique lo siguiente:" +
                                "\n - Asegúrese de que el campo 'Id' solo contenga caracteres numéricos." +
                                "\n - Asegúrese de seleccionar por lo menos 1 Articulo." +
                                "\n - Asegúrese de que ningun campo está vacío.");
            }
            textBox1.Text = "";
        }
    }
}
