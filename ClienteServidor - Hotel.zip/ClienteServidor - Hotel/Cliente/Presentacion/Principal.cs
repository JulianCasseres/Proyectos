﻿using System;
using System.Windows.Forms;
using Entidades;

namespace Presentacion
{
    public partial class Principal : Form
    {
        Cliente cliente;
        bool estado = false;

        public Principal()
        {
            InitializeComponent();
            comboBox1.Enabled = false;
            button2.Enabled = false;
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string identificacion = textBox1.Text;
                if (TCP.ConectarCliente(identificacion))
                {
                    cliente = TCP.ObtenerCliente(identificacion);
                    if (cliente != null)
                    {
                        if (TCP.EstadoConexion(identificacion) == false)
                        {
                            estado = true;
                            comboBox1.Enabled = true;
                            button1.Enabled = false;
                            button2.Enabled = true;
                            textBox1.Enabled = false;
                            MessageBox.Show("Bienvenido");
                        }
                        else
                        {
                            MessageBox.Show("Cliente ya conectado");
                            button2_Click(sender, e);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cliente No encontrado en la base de datos");
                        button2_Click(sender, e);
                    }
                }
                else
                {
                    MessageBox.Show("El servidor está apagado, espere a que se inicie para poder conectarse");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error al conectarse al servidor");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string identificacion = textBox1.Text;
                TCP.DesconectarCliente(identificacion);
                comboBox1.Enabled = false;
                button1.Enabled = true;
                button2.Enabled = false;
                textBox1.Text = "";
                textBox1.Enabled = true;
                estado = false;
            }
            catch (Exception)
            {
                MessageBox.Show("Error al desconectarse del servidor");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 1:
                    RealizarPedido realizar = new RealizarPedido(cliente, this);
                    realizar.Visible = true;
                    this.Visible = false;
                    break;

                case 2:
                    ConsultarPedidos consultar = new ConsultarPedidos(cliente, this);
                    consultar.Visible = true;
                    this.Visible = false;
                    break;

                default:
                    break;
            }
            comboBox1.SelectedIndex = 0;
        }

        private void Principal_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (estado)
                {
                    TCP.DesconectarCliente(cliente.Identificacion);
                }
            }
        }
    }
}
